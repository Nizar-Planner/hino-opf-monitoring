import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import {
  getDb,
  getAllOpfRecords,
  insertOrUpdateOpf,
  deleteOpfRecord,
  getOpfStats,
  getRecentSyncLogs,
  OpfRecord
} from './src/server/db.js';
import {
  initScraperSchedule,
  runHisScraper,
  getScraperStatus
} from './src/server/scraper.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const isProduction = process.env.NODE_ENV === 'production';

app.use(express.json());

// API Endpoints

// 1. Health check
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'online',
    app: 'Hino OPF Monitoring & Tracking Dashboard',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
  });
});

// 2. Get OPF Records with optional search
app.get('/api/opf', async (req, res) => {
  try {
    const search = typeof req.query.search === 'string' ? req.query.search : '';
    const records = await getAllOpfRecords(search);
    res.json({ success: true, data: records, count: records.length });
  } catch (error) {
    console.error('Error fetching OPF records:', error);
    res.status(500).json({ success: false, error: 'Gagal mengambil data OPF.' });
  }
});

// 3. Create or Update OPF Record
app.post('/api/opf', async (req, res) => {
  try {
    const record: OpfRecord = req.body;
    if (!record.dtr_number || !record.part_name || !record.chassis_number) {
      return res.status(400).json({
        success: false,
        error: 'Nomor DTR, Part Name, dan No. Chassis wajib diisi.',
      });
    }

    const result = await insertOrUpdateOpf(record);
    res.json({
      success: true,
      isNew: result.isNew,
      message: result.isNew ? 'Data OPF baru berhasil ditambahkan.' : 'Data OPF berhasil diperbarui.',
    });
  } catch (error) {
    console.error('Error saving OPF record:', error);
    res.status(500).json({ success: false, error: 'Gagal menyimpan data OPF.' });
  }
});

// 4. Delete OPF Record
app.delete('/api/opf/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, error: 'ID tidak valid.' });
    }
    await deleteOpfRecord(id);
    res.json({ success: true, message: 'Data OPF berhasil dihapus.' });
  } catch (error) {
    console.error('Error deleting OPF record:', error);
    res.status(500).json({ success: false, error: 'Gagal menghapus data OPF.' });
  }
});

// 5. Get Analytics & Statistics
app.get('/api/stats', async (_req, res) => {
  try {
    const stats = await getOpfStats();
    res.json({ success: true, data: stats });
  } catch (error) {
    console.error('Error fetching stats:', error);
    res.status(500).json({ success: false, error: 'Gagal mengambil statistik data.' });
  }
});

// 6. Robot Scraper Status
app.get('/api/sync/status', (_req, res) => {
  const status = getScraperStatus();
  res.json({ success: true, data: status });
});

// 7. Recent Sync Logs
app.get('/api/sync/logs', async (_req, res) => {
  try {
    const logs = await getRecentSyncLogs(20);
    res.json({ success: true, data: logs });
  } catch (error) {
    console.error('Error fetching sync logs:', error);
    res.status(500).json({ success: false, error: 'Gagal mengambil log sinkronisasi.' });
  }
});

// 8. Manually trigger Robot Scraper
app.post('/api/sync/trigger', async (req, res) => {
  const forceSimulate = req.query.simulate === 'true' || req.body?.simulate === true;
  try {
    const result = await runHisScraper(forceSimulate);
    res.json({ success: result.success, data: result });
  } catch (error) {
    console.error('Error triggering scraper:', error);
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Gagal memicu sinkronisasi.',
    });
  }
});

// 9. Export OPF Data as CSV
app.get('/api/export/csv', async (_req, res) => {
  try {
    const records = await getAllOpfRecords();
    const headers = [
      'ID',
      'Nomor DTR',
      'Part Name',
      'Quantity',
      'Model',
      'No. Chassis',
      'No. Engine',
      'Mileage (km)',
      'Dealer Name',
      'Judgement Date',
      'Judgement QPI',
      'Nama Pemilik',
      'Status Stage',
      'Status Detail',
      'Failure Symptom'
    ];

    const escapeCsv = (val: unknown) => {
      const str = String(val ?? '').replace(/"/g, '""');
      return `"${str}"`;
    };

    const csvRows = [headers.join(',')];
    for (const r of records) {
      csvRows.push([
        r.id,
        escapeCsv(r.dtr_number),
        escapeCsv(r.part_name),
        r.quantity,
        escapeCsv(r.model),
        escapeCsv(r.chassis_number),
        escapeCsv(r.engine_number),
        r.mileage,
        escapeCsv(r.dealer_name),
        escapeCsv(r.judgement_date),
        escapeCsv(r.judgement_qpi),
        escapeCsv(r.owner_name),
        escapeCsv(r.status_stage),
        escapeCsv(r.status_detail),
        escapeCsv(r.failure_symptom)
      ].join(','));
    }

    const csvContent = csvRows.join('\r\n');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="hino_opf_export_${new Date().toISOString().split('T')[0]}.csv"`);
    res.send(csvContent);
  } catch (error) {
    console.error('Error exporting CSV:', error);
    res.status(500).send('Gagal mengekspor CSV');
  }
});

// Setup Frontend Serving
async function startServer() {
  // Initialize SQLite DB
  await getDb();
  console.log('[DATABASE] SQLite berhasil dimuat.');

  // Initialize HIS Scraper background scheduler (default 3 hours)
  initScraperSchedule();

  if (!isProduction) {
    // Development mode with Vite dev server middleware
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
    console.log('[DEV] Vite dev middleware terhubung ke Express.');
  } else {
    // Production mode with built static assets
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
    console.log('[PROD] Serving static production build dari dist.');
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`====================================================`);
    console.log(`🚚 Hino OPF Dashboard berjalan di http://0.0.0.0:${PORT}`);
    console.log(`====================================================`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err);
  process.exit(1);
});
