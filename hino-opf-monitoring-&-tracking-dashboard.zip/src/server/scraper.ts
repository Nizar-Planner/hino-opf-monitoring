import puppeteer from 'puppeteer-core';
import fs from 'fs';
import { insertOrUpdateOpf, addSyncLog, OpfRecord } from './db.js';

export interface ScraperStatus {
  isRunning: boolean;
  lastRunTimestamp: string | null;
  lastRunStatus: 'idle' | 'success' | 'failed' | 'simulated';
  lastRunMessage: string;
  nextScheduledRun: string | null;
  totalSyncedCount: number;
}

const status: ScraperStatus = {
  isRunning: false,
  lastRunTimestamp: null,
  lastRunStatus: 'idle',
  lastRunMessage: 'Robot belum pernah dijalankan sejak server aktif.',
  nextScheduledRun: null,
  totalSyncedCount: 0,
};

let syncTimer: NodeJS.Timeout | null = null;

export function getScraperStatus(): ScraperStatus {
  return { ...status };
}

/**
 * Schedule automated extraction every N hours (default 3 hours)
 */
export function initScraperSchedule(): void {
  const intervalHours = Number(process.env.SYNC_INTERVAL_HOURS) || 3;
  const intervalMs = intervalHours * 60 * 60 * 1000;

  const updateNextSchedule = () => {
    const nextDate = new Date(Date.now() + intervalMs);
    status.nextScheduledRun = nextDate.toISOString();
  };

  updateNextSchedule();

  if (syncTimer) {
    clearInterval(syncTimer);
  }

  // Set recurring interval
  syncTimer = setInterval(async () => {
    console.log(`[ROBOT HIS] Menjalankan sinkronisasi terjadwal (${intervalHours} jam)...`);
    try {
      await runHisScraper();
    } catch (err) {
      console.error('[ROBOT HIS] Error pada sinkronisasi terjadwal:', err);
    }
    updateNextSchedule();
  }, intervalMs);

  console.log(`[ROBOT HIS] Scheduler aktif: Sinkronisasi setiap ${intervalHours} jam.`);
}

/**
 * Main Scraper Engine
 */
export async function runHisScraper(forceSimulate = false): Promise<{
  success: boolean;
  message: string;
  recordsExtracted: number;
  recordsNew: number;
  recordsUpdated: number;
  isSimulated: boolean;
}> {
  if (status.isRunning) {
    return {
      success: false,
      message: 'Proses sinkronisasi sedang berjalan. Harap tunggu.',
      recordsExtracted: 0,
      recordsNew: 0,
      recordsUpdated: 0,
      isSimulated: false,
    };
  }

  status.isRunning = true;
  const startTime = Date.now();
  const timestamp = new Date().toISOString();

  const hisUser = process.env.HIS_USER?.trim();
  const hisPassword = process.env.HIS_PASSWORD?.trim();
  const hisUrl = process.env.HIS_URL || 'https://his.hino.co.id/portal';
  const executablePath = process.env.PUPPETEER_EXECUTABLE_PATH || '/usr/bin/chromium';

  const hasChromium = fs.existsSync(executablePath) || fs.existsSync('/usr/bin/google-chrome') || fs.existsSync('/usr/bin/chromium-browser');
  const hasCredentials = Boolean(hisUser && hisPassword);

  // If forced simulate or missing credentials / browser binary in dev
  if (forceSimulate || !hasCredentials || !hasChromium) {
    const reason = !hasCredentials
      ? 'Kredensial HIS_USER atau HIS_PASSWORD belum dikonfigurasi di Environment Variables.'
      : !hasChromium
      ? `Binary Chromium tidak ditemukan di ${executablePath}. (Normal pada lingkungan lokal dev).`
      : 'Mode simulasi manual diminta oleh pengguna.';

    console.log(`[ROBOT HIS] ${reason} Menggunakan simulated extractor.`);
    const result = await runSimulatedScraper();
    const duration = Date.now() - startTime;

    status.isRunning = false;
    status.lastRunTimestamp = timestamp;
    status.lastRunStatus = 'simulated';
    status.lastRunMessage = `Sinkronisasi Simulasi: ${result.recordsExtracted} data diproses (${result.recordsNew} baru, ${result.recordsUpdated} update). ${reason}`;
    status.totalSyncedCount += result.recordsExtracted;

    await addSyncLog({
      timestamp,
      status: 'success',
      records_extracted: result.recordsExtracted,
      records_new: result.recordsNew,
      records_updated: result.recordsUpdated,
      message: status.lastRunMessage,
      duration_ms: duration,
    });

    return {
      success: true,
      message: status.lastRunMessage,
      recordsExtracted: result.recordsExtracted,
      recordsNew: result.recordsNew,
      recordsUpdated: result.recordsUpdated,
      isSimulated: true,
    };
  }

  // Real Puppeteer Scraping Pipeline
  let browser = null;
  try {
    console.log(`[ROBOT HIS] Meluncurkan Chromium headless di ${executablePath}...`);
    browser = await puppeteer.launch({
      executablePath,
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-gpu',
        '--no-first-run',
        '--no-zygote',
        '--single-process',
      ],
    });

    const page = await browser.newPage();
    await page.setViewport({ width: 1366, height: 768 });
    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');

    console.log(`[ROBOT HIS] Mengakses portal login HIS di ${hisUrl}...`);
    await page.goto(hisUrl, { waitUntil: 'networkidle2', timeout: 30000 });

    // Login process
    const userField = await page.$('input[name="username"], input[name="user"], input[id="username"], input[type="text"]');
    const passField = await page.$('input[name="password"], input[type="password"]');
    const submitBtn = await page.$('button[type="submit"], input[type="submit"], .btn-login, #btnLogin');

    if (userField && passField) {
      await userField.type(hisUser!);
      await passField.type(hisPassword!);

      if (submitBtn) {
        await Promise.all([
          page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 30000 }).catch(() => null),
          submitBtn.click(),
        ]);
      } else {
        await page.keyboard.press('Enter');
        await page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 30000 }).catch(() => null);
      }
    }

    console.log('[ROBOT HIS] Login form submitted, navigating to OPF / DTR claim menu...');

    // Navigate to OPF / DTR page if separate
    const opfUrl = `${hisUrl}/claim/dtr-opf-monitoring`;
    await page.goto(opfUrl, { waitUntil: 'networkidle2', timeout: 30000 }).catch(() => null);

    // Extract table rows
    const extractedRows = await page.evaluate(() => {
      const rows: Array<{
        dtr_number: string;
        part_name: string;
        quantity: number;
        model: string;
        chassis_number: string;
        engine_number: string;
        mileage: number;
        dealer_name: string;
        judgement_date: string;
        judgement_qpi: string;
        owner_name: string;
        status_stage: 'Dealer' | 'HMSI' | 'HMMI/HML';
        status_detail: string;
        failure_symptom: string;
      }> = [];

      const trList = document.querySelectorAll('table tbody tr');
      trList.forEach((tr) => {
        const cells = tr.querySelectorAll('td');
        if (cells.length >= 8) {
          const dtr = cells[0]?.textContent?.trim() || '';
          const part = cells[1]?.textContent?.trim() || '';
          const qty = parseInt(cells[2]?.textContent?.trim() || '1', 10) || 1;
          const model = cells[3]?.textContent?.trim() || '';
          const chassis = cells[4]?.textContent?.trim() || '';
          const engine = cells[5]?.textContent?.trim() || '';
          const mileage = parseInt(cells[6]?.textContent?.replace(/\D/g, '') || '0', 10) || 0;
          const dealer = cells[7]?.textContent?.trim() || '';
          const jDate = cells[8]?.textContent?.trim() || new Date().toISOString().split('T')[0];
          const jQpi = cells[9]?.textContent?.trim() || 'In Review';
          const owner = cells[10]?.textContent?.trim() || 'PT Hino Armada';

          if (dtr && part) {
            let stage: 'Dealer' | 'HMSI' | 'HMMI/HML' = 'Dealer';
            if (jQpi.toLowerCase().includes('hmmi') || jQpi.toLowerCase().includes('hml') || jQpi.toLowerCase().includes('approved')) {
              stage = 'HMMI/HML';
            } else if (jQpi.toLowerCase().includes('hmsi') || jQpi.toLowerCase().includes('review')) {
              stage = 'HMSI';
            }

            rows.push({
              dtr_number: dtr,
              part_name: part,
              quantity: qty,
              model: model || 'Hino 500 FM 260 JD',
              chassis_number: chassis || 'MHFJ1JGBMK000000',
              engine_number: engine || 'J08E-WD00000',
              mileage,
              dealer_name: dealer || 'PT Duta Cemerlang Motors',
              judgement_date: jDate,
              judgement_qpi: jQpi,
              owner_name: owner,
              status_stage: stage,
              status_detail: jQpi,
              failure_symptom: 'Extracted from HIS portal automatically',
            });
          }
        }
      });

      return rows;
    });

    console.log(`[ROBOT HIS] Berhasil mengekstrak ${extractedRows.length} baris dari portal HIS.`);

    let newCount = 0;
    let updateCount = 0;

    for (const record of extractedRows) {
      const res = await insertOrUpdateOpf(record);
      if (res.isNew) newCount++;
      else updateCount++;
    }

    const duration = Date.now() - startTime;
    status.isRunning = false;
    status.lastRunTimestamp = timestamp;
    status.lastRunStatus = 'success';
    status.lastRunMessage = `Robot HIS sukses mengekstrak ${extractedRows.length} data (${newCount} baru, ${updateCount} update).`;
    status.totalSyncedCount += extractedRows.length;

    await addSyncLog({
      timestamp,
      status: 'success',
      records_extracted: extractedRows.length,
      records_new: newCount,
      records_updated: updateCount,
      message: status.lastRunMessage,
      duration_ms: duration,
    });

    return {
      success: true,
      message: status.lastRunMessage,
      recordsExtracted: extractedRows.length,
      recordsNew: newCount,
      recordsUpdated: updateCount,
      isSimulated: false,
    };
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : String(error);
    console.error('[ROBOT HIS] Gagal mengeksekusi penarikan data:', errorMsg);

    const duration = Date.now() - startTime;
    status.isRunning = false;
    status.lastRunTimestamp = timestamp;
    status.lastRunStatus = 'failed';
    status.lastRunMessage = `Gagal menarik data dari HIS: ${errorMsg}`;

    await addSyncLog({
      timestamp,
      status: 'failed',
      records_extracted: 0,
      records_new: 0,
      records_updated: 0,
      message: status.lastRunMessage,
      duration_ms: duration,
    });

    return {
      success: false,
      message: status.lastRunMessage,
      recordsExtracted: 0,
      recordsNew: 0,
      recordsUpdated: 0,
      isSimulated: false,
    };
  } finally {
    if (browser) {
      await browser.close().catch(() => null);
    }
  }
}

/**
 * Simulated Scraper:
 * Generates realistic incoming HIS data updates to test live pipeline
 */
async function runSimulatedScraper(): Promise<{
  recordsExtracted: number;
  recordsNew: number;
  recordsUpdated: number;
}> {
  const partsPool = [
    { name: 'Turbocharger Assembly', models: ['Hino 500 FM 260 JD', 'Hino 500 FM 350 TH'] },
    { name: 'King Pin & Bushing Set', models: ['Hino Dutro 300 130 HD', 'Hino 500 FL 260 JW'] },
    { name: 'Leaf Spring Rear No. 1', models: ['Hino 500 FM 260 JD', 'Hino Dutro 300 130 HD'] },
    { name: 'Clutch Booster Assembly', models: ['Hino 500 FM 260 JD', 'Hino 500 FG 235 JJ'] },
    { name: 'Common Rail High Pressure Pump', models: ['Hino 500 FG 235 JJ', 'Hino 500 FL 260 JW'] },
    { name: 'Brake Chamber Rear Diaphragm', models: ['Hino Dutro 300 130 HD', 'Hino 500 FM 260 JD'] },
    { name: 'Water Pump Assembly', models: ['Hino Dutro 300 110 SDB', 'Hino Dutro 300 130 HD'] },
    { name: 'Universal Joint Propeller Shaft', models: ['Hino 500 FM 260 JD', 'Hino 500 FM 350 TH'] },
  ];

  const dealers = [
    'PT Duta Cemerlang Motors - Jakarta Barat',
    'PT Indomobil Prima Niaga - Surabaya',
    'PT Maya Graha Indah - Bandung',
    'PT Hibaindah Armada Motor - Balikpapan',
    'PT Kumala Motor Sejahtera - Makassar',
    'PT Indomobil Prima Niaga - Medan',
    'PT Duta Cemerlang Motors - Semarang',
  ];

  const owners = [
    'PT Sinar Mas Logistik',
    'PT Samudera Sawit Sejahtera',
    'CV Sumber Rejeki Express',
    'PT Kutai Bara Energi',
    'PT Mitra Tambang Persada',
    'PO Riau Transport Prima',
    'CV Way Kanan Karya Mandiri',
  ];

  const stages: Array<{ stage: 'Dealer' | 'HMSI' | 'HMMI/HML'; detail: string; qpi: string }> = [
    { stage: 'Dealer', detail: 'Draft - Menunggu Foto Fisik & Tag OPF', qpi: 'Pending Review' },
    { stage: 'Dealer', detail: 'Submitted - Terkirim ke HMSI Technical Service', qpi: 'Draft QPI' },
    { stage: 'HMSI', detail: 'Screening HMSI - Waiting Technical Feedback', qpi: 'QPI-HMSI-26-0511 (Under Evaluation)' },
    { stage: 'HMSI', detail: 'Processed - Forwarded to HMMI QA Factory', qpi: 'QPI-HMSI-26-0542 (Approved for Factory Review)' },
    { stage: 'HMMI/HML', detail: 'Approved - Part Replaced & Warranty Reimbursed', qpi: 'QPI-HMMI-26-0922 (Final Approved)' },
    { stage: 'HMMI/HML', detail: 'Completed - HML Japan QA Cleared', qpi: 'QPI-HML-26-0104 (Factory Verified)' },
  ];

  const randomNum = Math.floor(1000 + Math.random() * 9000);
  const cityCode = ['JKT', 'SBY', 'BDG', 'MDN', 'SMG', 'BPP', 'MKS'][Math.floor(Math.random() * 7)];
  const randomPart = partsPool[Math.floor(Math.random() * partsPool.length)];
  const randomModel = randomPart.models[Math.floor(Math.random() * randomPart.models.length)];
  const randomDealer = dealers[Math.floor(Math.random() * dealers.length)];
  const randomOwner = owners[Math.floor(Math.random() * owners.length)];
  const randomStage = stages[Math.floor(Math.random() * stages.length)];

  const newRecord: OpfRecord = {
    dtr_number: `DTR-2026-${cityCode}-${randomNum}`,
    part_name: randomPart.name,
    quantity: Math.random() > 0.7 ? 2 : 1,
    model: randomModel,
    chassis_number: `MHFJ1JG${Math.random() > 0.5 ? 'B' : 'C'}MK0${Math.floor(10000 + Math.random() * 90000)}`,
    engine_number: `J08E-WD${Math.floor(10000 + Math.random() * 90000)}`,
    mileage: Math.floor(12000 + Math.random() * 85000),
    dealer_name: randomDealer,
    judgement_date: new Date().toISOString().split('T')[0],
    judgement_qpi: randomStage.qpi,
    owner_name: randomOwner,
    status_stage: randomStage.stage,
    status_detail: randomStage.detail,
    failure_symptom: 'Ditarik otomatis dari sistem HIS pada siklus inspeksi terjadwal.',
  };

  const insertRes = await insertOrUpdateOpf(newRecord);

  return {
    recordsExtracted: 1,
    recordsNew: insertRes.isNew ? 1 : 0,
    recordsUpdated: insertRes.isNew ? 0 : 1,
  };
}
