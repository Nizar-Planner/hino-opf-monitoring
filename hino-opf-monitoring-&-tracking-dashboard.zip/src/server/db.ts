import initSqlJs, { Database, SqlValue } from 'sql.js';
import fs from 'fs';
import path from 'path';

export interface OpfRecord {
  id?: number;
  dtr_number: string;
  part_name: string;
  quantity: number;
  model: string;
  chassis_number: string;
  engine_number: string;
  mileage: number;
  dealer_name: string;
  judgement_date: string;
  judgement_qpi: string;
  owner_name: string;
  status_stage: 'Dealer' | 'HMSI' | 'HMMI/HML';
  status_detail: string;
  failure_symptom?: string;
  created_at?: string;
  updated_at?: string;
}

export interface SyncLog {
  id?: number;
  timestamp: string;
  status: 'success' | 'failed' | 'running';
  records_extracted: number;
  records_new: number;
  records_updated: number;
  message: string;
  duration_ms: number;
}

let dbInstance: Database | null = null;
const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_PATH = path.join(DATA_DIR, 'opf_database.sqlite');

/**
 * Initialize SQLite database using SQL.js (WASM) and persist to disk
 */
export async function getDb(): Promise<Database> {
  if (dbInstance) {
    return dbInstance;
  }

  // Ensure data directory exists
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  const SQL = await initSqlJs();

  if (fs.existsSync(DB_PATH)) {
    try {
      const fileBuffer = fs.readFileSync(DB_PATH);
      dbInstance = new SQL.Database(fileBuffer);
    } catch (err) {
      console.warn('Existing database file could not be read. Initializing new database.', err);
      dbInstance = new SQL.Database();
    }
  } else {
    dbInstance = new SQL.Database();
  }

  // Create tables if not exist
  createTables(dbInstance);

  // Seed sample Hino OPF data if empty
  seedInitialData(dbInstance);

  saveDb();
  return dbInstance;
}

/**
 * Save in-memory SQLite database to disk file
 */
export function saveDb(): void {
  if (!dbInstance) return;
  try {
    const data = dbInstance.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  } catch (err) {
    console.error('Failed to save SQLite database to disk:', err);
  }
}

function createTables(db: Database): void {
  db.run(`
    CREATE TABLE IF NOT EXISTS opf_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      dtr_number TEXT UNIQUE NOT NULL,
      part_name TEXT NOT NULL,
      quantity INTEGER NOT NULL DEFAULT 1,
      model TEXT NOT NULL,
      chassis_number TEXT NOT NULL,
      engine_number TEXT NOT NULL,
      mileage INTEGER NOT NULL DEFAULT 0,
      dealer_name TEXT NOT NULL,
      judgement_date TEXT NOT NULL,
      judgement_qpi TEXT NOT NULL,
      owner_name TEXT NOT NULL,
      status_stage TEXT NOT NULL DEFAULT 'Dealer',
      status_detail TEXT NOT NULL DEFAULT 'Draft',
      failure_symptom TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS sync_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp TEXT NOT NULL,
      status TEXT NOT NULL,
      records_extracted INTEGER DEFAULT 0,
      records_new INTEGER DEFAULT 0,
      records_updated INTEGER DEFAULT 0,
      message TEXT,
      duration_ms INTEGER DEFAULT 0
    );
  `);
}

function seedInitialData(db: Database): void {
  const result = db.exec('SELECT COUNT(*) as count FROM opf_records');
  const count = (result.length > 0 && result[0].values.length > 0) ? (result[0].values[0][0] as number) : 0;

  if (count > 0) return;

  const sampleRecords: OpfRecord[] = [
    {
      dtr_number: 'DTR-2026-JKT-0041',
      part_name: 'Turbocharger Assembly',
      quantity: 1,
      model: 'Hino 500 FM 260 JD (6x4 Dump)',
      chassis_number: 'MHFJ1JGBMK002491',
      engine_number: 'J08E-WD28412',
      mileage: 48200,
      dealer_name: 'PT Duta Cemerlang Motors - Jakarta Barat',
      judgement_date: '2026-10-12',
      judgement_qpi: 'QPI-HMMI-26-0881 (Approved)',
      owner_name: 'PT Mitra Tambang Persada',
      status_stage: 'HMMI/HML',
      status_detail: 'Approved - Part Replaced',
      failure_symptom: 'Shaft impeller unbalance, kebocoran oli ke sisi kompresor pada pemakaian heavy duty tambang.'
    },
    {
      dtr_number: 'DTR-2026-SBY-0094',
      part_name: 'King Pin & Bushing Set',
      quantity: 2,
      model: 'Hino Dutro 300 130 HD (4x2)',
      chassis_number: 'MHFW1JGAMK018432',
      engine_number: 'W04D-TN99214',
      mileage: 32450,
      dealer_name: 'PT Indomobil Prima Niaga - Surabaya',
      judgement_date: '2026-10-14',
      judgement_qpi: 'QPI-HMSI-26-0412 (Reviewed)',
      owner_name: 'CV Sumber Rejeki Logistik',
      status_stage: 'HMSI',
      status_detail: 'Screening HMSI - Waiting Technical Feedback',
      failure_symptom: 'Spelling berlebih pada kemudi roda depan kiri dan kanan, getaran kemudi pada kecepatan 50 km/h.'
    },
    {
      dtr_number: 'DTR-2026-MDN-0018',
      part_name: 'Leaf Spring Rear No. 1',
      quantity: 1,
      model: 'Hino 500 FL 260 JW (6x2 Cargo)',
      chassis_number: 'MHFJ1JGCMK009182',
      engine_number: 'J08E-WE19844',
      mileage: 61300,
      dealer_name: 'PT Indomobil Prima Niaga - Medan',
      judgement_date: '2026-10-15',
      judgement_qpi: 'Pending Review',
      owner_name: 'PT Samudera Sawit Sejahtera',
      status_stage: 'Dealer',
      status_detail: 'Draft - Menunggu Foto Fisik & Tag OPF',
      failure_symptom: 'Patah pada lembar per nomor 1 dekat eye bush suspensi belakang sebelah kanan.'
    },
    {
      dtr_number: 'DTR-2026-BDG-0072',
      part_name: 'Clutch Booster Assembly',
      quantity: 1,
      model: 'Hino 500 FM 260 JD (6x4 Dump)',
      chassis_number: 'MHFJ1JGBMK003102',
      engine_number: 'J08E-WD31089',
      mileage: 29800,
      dealer_name: 'PT Maya Graha Indah - Bandung',
      judgement_date: '2026-10-10',
      judgement_qpi: 'QPI-HMMI-26-0810 (Approved)',
      owner_name: 'PT Graha Bangun Konstruksi',
      status_stage: 'HMMI/HML',
      status_detail: 'Completed - Claim Reimbursed',
      failure_symptom: 'Pedal kopling keras saat diinjak, kebocoran angin pada valve relay booster.'
    },
    {
      dtr_number: 'DTR-2026-SMG-0033',
      part_name: 'Common Rail High Pressure Pump',
      quantity: 1,
      model: 'Hino 500 FG 235 JJ (4x2)',
      chassis_number: 'MHFJ1JGDMK004812',
      engine_number: 'J08E-UG12044',
      mileage: 51200,
      dealer_name: 'PT Duta Cemerlang Motors - Semarang',
      judgement_date: '2026-10-13',
      judgement_qpi: 'QPI-HMSI-26-0498 (Under Investigation)',
      owner_name: 'PT Sinar Jaya Express',
      status_stage: 'HMSI',
      status_detail: 'Processed - Fuel Sample Analysis at HMSI Lab',
      failure_symptom: 'Mesin hunting dan mati mendadak saat akselerasi, pressure fuel rail drop di bawah 30 MPa.'
    },
    {
      dtr_number: 'DTR-2026-BPP-0021',
      part_name: 'Turbocharger Assembly',
      quantity: 1,
      model: 'Hino 500 FM 350 TH (Tractor Head)',
      chassis_number: 'MHFJ1JTHMK001092',
      engine_number: 'P11C-VP10922',
      mileage: 72100,
      dealer_name: 'PT Hibaindah Armada Motor - Balikpapan',
      judgement_date: '2026-10-08',
      judgement_qpi: 'QPI-HMMI-26-0792 (Analysis Complete)',
      owner_name: 'PT Kutai Bara Energi',
      status_stage: 'HMMI/HML',
      status_detail: 'Completed - HML Japan QA Cleared',
      failure_symptom: 'Bunyi siulan keras (high pitch whistle) dari turbin, thrust bearing aus abnormal.'
    },
    {
      dtr_number: 'DTR-2026-MKS-0056',
      part_name: 'Brake Chamber Rear Diaphragm',
      quantity: 2,
      model: 'Hino Dutro 300 130 HD (4x2 Dump)',
      chassis_number: 'MHFW1JGAMK022091',
      engine_number: 'W04D-TN84910',
      mileage: 18400,
      dealer_name: 'PT Kumala Motor Sejahtera - Makassar',
      judgement_date: '2026-10-15',
      judgement_qpi: 'Draft QPI',
      owner_name: 'CV Celebes Agroniaga',
      status_stage: 'Dealer',
      status_detail: 'Submitted - Sent to HMSI Technical Service',
      failure_symptom: 'Kebocoran angin saat rem parkir dilepas, karet diafragma sobek prematur.'
    },
    {
      dtr_number: 'DTR-2026-PLB-0065',
      part_name: 'King Pin & Bushing Set',
      quantity: 2,
      model: 'Hino 500 FL 260 JW (6x2 Cargo)',
      chassis_number: 'MHFJ1JGCMK011033',
      engine_number: 'J08E-WE22091',
      mileage: 38900,
      dealer_name: 'PT Indomobil Prima Niaga - Palembang',
      judgement_date: '2026-10-11',
      judgement_qpi: 'QPI-HMSI-26-0466 (Passed Inspection)',
      owner_name: 'PT Musi Kirana Logistik',
      status_stage: 'HMSI',
      status_detail: 'Processed - Forwarded to HMMI QA Factory',
      failure_symptom: 'Bushing knuckle aus tidak merata, pelumasan grease normal sesuai buku servis.'
    },
    {
      dtr_number: 'DTR-2026-PKU-0012',
      part_name: 'Water Pump Assembly',
      quantity: 1,
      model: 'Hino Dutro 300 110 SDB (4x2 Microbus)',
      chassis_number: 'MHFW1JSBMK008122',
      engine_number: 'W04D-TM11094',
      mileage: 44300,
      dealer_name: 'PT Duta Cemerlang Motors - Pekanbaru',
      judgement_date: '2026-10-05',
      judgement_qpi: 'QPI-HMMI-26-0744 (Approved)',
      owner_name: 'PO Riau Transport Prima',
      status_stage: 'HMMI/HML',
      status_detail: 'Approved - Part Replaced',
      failure_symptom: 'Kebocoran air pendingin pada weep hole mechanical seal water pump.'
    },
    {
      dtr_number: 'DTR-2026-LMP-0029',
      part_name: 'Leaf Spring Rear No. 1',
      quantity: 1,
      model: 'Hino 500 FM 260 JD (6x4 Dump)',
      chassis_number: 'MHFJ1JGBMK004491',
      engine_number: 'J08E-WD44199',
      mileage: 27500,
      dealer_name: 'PT Maya Graha Indah - Lampung',
      judgement_date: '2026-10-16',
      judgement_qpi: 'Pending Review',
      owner_name: 'CV Way Kanan Karya Mandiri',
      status_stage: 'Dealer',
      status_detail: 'Draft - Menunggu Approval Kepala Bengkel',
      failure_symptom: 'Per daun belakang patah di area center bolt saat muatan standar 12 kubik.'
    }
  ];

  for (const item of sampleRecords) {
    db.run(
      `INSERT INTO opf_records 
      (dtr_number, part_name, quantity, model, chassis_number, engine_number, mileage, dealer_name, judgement_date, judgement_qpi, owner_name, status_stage, status_detail, failure_symptom) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        item.dtr_number,
        item.part_name,
        item.quantity,
        item.model,
        item.chassis_number,
        item.engine_number,
        item.mileage,
        item.dealer_name,
        item.judgement_date,
        item.judgement_qpi,
        item.owner_name,
        item.status_stage,
        item.status_detail,
        item.failure_symptom || ''
      ]
    );
  }

  // Initial sync log
  db.run(
    `INSERT INTO sync_logs (timestamp, status, records_extracted, records_new, records_updated, message, duration_ms)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [
      new Date().toISOString(),
      'success',
      sampleRecords.length,
      sampleRecords.length,
      0,
      'Sistem awal berhasil diinisialisasi dengan data histori OPF Hino.',
      1420
    ]
  );
}

export async function getAllOpfRecords(query = ''): Promise<OpfRecord[]> {
  const db = await getDb();
  let sql = 'SELECT * FROM opf_records';
  let params: SqlValue[] = [];

  if (query.trim()) {
    const q = `%${query.trim()}%`;
    sql += ` WHERE dtr_number LIKE ? 
             OR part_name LIKE ? 
             OR model LIKE ? 
             OR chassis_number LIKE ? 
             OR engine_number LIKE ? 
             OR dealer_name LIKE ? 
             OR judgement_qpi LIKE ? 
             OR owner_name LIKE ?`;
    params = [q, q, q, q, q, q, q, q];
  }

  sql += ' ORDER BY id DESC';

  const stmt = db.prepare(sql);
  if (params.length > 0) {
    stmt.bind(params);
  }

  const records: OpfRecord[] = [];
  while (stmt.step()) {
    const row = stmt.getAsObject();
    records.push(row as unknown as OpfRecord);
  }
  stmt.free();

  return records;
}

export async function insertOrUpdateOpf(record: OpfRecord): Promise<{ isNew: boolean; id?: number }> {
  const db = await getDb();
  
  // Check if exists
  const checkStmt = db.prepare('SELECT id FROM opf_records WHERE dtr_number = ?');
  checkStmt.bind([record.dtr_number]);
  const exists = checkStmt.step();
  let existingId: number | undefined;
  if (exists) {
    const row = checkStmt.getAsObject();
    existingId = row.id as number;
  }
  checkStmt.free();

  if (exists && existingId) {
    db.run(
      `UPDATE opf_records 
       SET part_name = ?, quantity = ?, model = ?, chassis_number = ?, engine_number = ?, 
           mileage = ?, dealer_name = ?, judgement_date = ?, judgement_qpi = ?, 
           owner_name = ?, status_stage = ?, status_detail = ?, failure_symptom = ?, 
           updated_at = datetime('now')
       WHERE id = ?`,
      [
        record.part_name,
        record.quantity,
        record.model,
        record.chassis_number,
        record.engine_number,
        record.mileage,
        record.dealer_name,
        record.judgement_date,
        record.judgement_qpi,
        record.owner_name,
        record.status_stage,
        record.status_detail,
        record.failure_symptom || '',
        existingId
      ]
    );
    saveDb();
    return { isNew: false, id: existingId };
  } else {
    db.run(
      `INSERT INTO opf_records 
       (dtr_number, part_name, quantity, model, chassis_number, engine_number, mileage, dealer_name, judgement_date, judgement_qpi, owner_name, status_stage, status_detail, failure_symptom)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        record.dtr_number,
        record.part_name,
        record.quantity,
        record.model,
        record.chassis_number,
        record.engine_number,
        record.mileage,
        record.dealer_name,
        record.judgement_date,
        record.judgement_qpi,
        record.owner_name,
        record.status_stage,
        record.status_detail,
        record.failure_symptom || ''
      ]
    );
    saveDb();
    return { isNew: true };
  }
}

export async function deleteOpfRecord(id: number): Promise<boolean> {
  const db = await getDb();
  db.run('DELETE FROM opf_records WHERE id = ?', [id]);
  saveDb();
  return true;
}

export async function getOpfStats(): Promise<{
  totalRecords: number;
  stageCounts: { dealer: number; hmsi: number; hmmi_hml: number };
  topParts: { name: string; count: number }[];
  modelDistribution: { model: string; count: number }[];
  recentActivity: OpfRecord[];
}> {
  const db = await getDb();

  // Total
  const totalRes = db.exec('SELECT COUNT(*) as count FROM opf_records');
  const totalRecords = totalRes.length > 0 ? (totalRes[0].values[0][0] as number) : 0;

  // Stages
  const stageRes = db.exec(`
    SELECT status_stage, COUNT(*) as count 
    FROM opf_records 
    GROUP BY status_stage
  `);
  
  const stageCounts = { dealer: 0, hmsi: 0, hmmi_hml: 0 };
  if (stageRes.length > 0) {
    for (const row of stageRes[0].values) {
      const stage = String(row[0]).toLowerCase();
      const count = Number(row[1]);
      if (stage.includes('dealer')) stageCounts.dealer += count;
      else if (stage.includes('hmsi')) stageCounts.hmsi += count;
      else if (stage.includes('hmmi') || stage.includes('hml')) stageCounts.hmmi_hml += count;
    }
  }

  // Top Parts (Top OPF)
  const topPartsRes = db.exec(`
    SELECT part_name, SUM(quantity) as total_qty
    FROM opf_records
    GROUP BY part_name
    ORDER BY total_qty DESC
    LIMIT 6
  `);
  const topParts: { name: string; count: number }[] = [];
  if (topPartsRes.length > 0) {
    for (const row of topPartsRes[0].values) {
      topParts.push({
        name: String(row[0]),
        count: Number(row[1])
      });
    }
  }

  // Model distribution
  const modelRes = db.exec(`
    SELECT model, COUNT(*) as count
    FROM opf_records
    GROUP BY model
    ORDER BY count DESC
    LIMIT 5
  `);
  const modelDistribution: { model: string; count: number }[] = [];
  if (modelRes.length > 0) {
    for (const row of modelRes[0].values) {
      modelDistribution.push({
        model: String(row[0]),
        count: Number(row[1])
      });
    }
  }

  // Recent 5
  const recentRecords = await getAllOpfRecords('');

  return {
    totalRecords,
    stageCounts,
    topParts,
    modelDistribution,
    recentActivity: recentRecords.slice(0, 5)
  };
}

export async function addSyncLog(log: Omit<SyncLog, 'id'>): Promise<void> {
  const db = await getDb();
  db.run(
    `INSERT INTO sync_logs (timestamp, status, records_extracted, records_new, records_updated, message, duration_ms)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [
      log.timestamp,
      log.status,
      log.records_extracted,
      log.records_new,
      log.records_updated,
      log.message,
      log.duration_ms
    ]
  );
  saveDb();
}

export async function getRecentSyncLogs(limit = 10): Promise<SyncLog[]> {
  const db = await getDb();
  const stmt = db.prepare('SELECT * FROM sync_logs ORDER BY id DESC LIMIT ?');
  stmt.bind([limit]);

  const logs: SyncLog[] = [];
  while (stmt.step()) {
    logs.push(stmt.getAsObject() as unknown as SyncLog);
  }
  stmt.free();
  return logs;
}
