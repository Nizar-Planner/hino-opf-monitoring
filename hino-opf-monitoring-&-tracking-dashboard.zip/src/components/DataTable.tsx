import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Eye,
  Trash2,
  SlidersHorizontal,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  Layers,
  Calendar,
  Truck,
  Hash,
  X
} from 'lucide-react';
import { OpfRecord } from '../types';

interface DataTableProps {
  records: OpfRecord[];
  isLoading: boolean;
  onSelectRecord: (record: OpfRecord) => void;
  onDeleteRecord: (id: number) => void;
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  activeStageFilter: 'all' | 'dealer' | 'hmsi' | 'hmmi_hml';
  setActiveStageFilter: (filter: 'all' | 'dealer' | 'hmsi' | 'hmmi_hml') => void;
}

export const DataTable: React.FC<DataTableProps> = ({
  records,
  isLoading,
  onSelectRecord,
  onDeleteRecord,
  searchTerm,
  setSearchTerm,
  activeStageFilter,
  setActiveStageFilter,
}) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [selectedDealer, setSelectedDealer] = useState<string>('all');

  // Unique dealers list for quick dropdown filter
  const dealersList = useMemo(() => {
    const set = new Set<string>();
    records.forEach((r) => {
      if (r.dealer_name) set.add(r.dealer_name);
    });
    return Array.from(set).sort();
  }, [records]);

  // Filter records based on search term, active stage, and dealer
  const filteredRecords = useMemo(() => {
    return records.filter((r) => {
      // Stage filter
      if (activeStageFilter === 'dealer' && !r.status_stage.toLowerCase().includes('dealer')) {
        return false;
      }
      if (activeStageFilter === 'hmsi' && !r.status_stage.toLowerCase().includes('hmsi')) {
        return false;
      }
      if (activeStageFilter === 'hmmi_hml' && !(r.status_stage.toLowerCase().includes('hmmi') || r.status_stage.toLowerCase().includes('hml'))) {
        return false;
      }

      // Dealer dropdown filter
      if (selectedDealer !== 'all' && r.dealer_name !== selectedDealer) {
        return false;
      }

      // Search term
      if (!searchTerm.trim()) return true;
      const term = searchTerm.toLowerCase();
      return (
        r.dtr_number?.toLowerCase().includes(term) ||
        r.part_name?.toLowerCase().includes(term) ||
        r.chassis_number?.toLowerCase().includes(term) ||
        r.engine_number?.toLowerCase().includes(term) ||
        r.dealer_name?.toLowerCase().includes(term) ||
        r.judgement_qpi?.toLowerCase().includes(term) ||
        r.owner_name?.toLowerCase().includes(term) ||
        r.model?.toLowerCase().includes(term)
      );
    });
  }, [records, searchTerm, activeStageFilter, selectedDealer]);

  // Pagination calculations
  const totalPages = Math.ceil(filteredRecords.length / itemsPerPage) || 1;
  const paginatedRecords = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredRecords.slice(start, start + itemsPerPage);
  }, [filteredRecords, currentPage, itemsPerPage]);

  const handleStageBadge = (stage: string) => {
    const lower = stage.toLowerCase();
    if (lower.includes('dealer')) {
      return (
        <span className="inline-flex items-center text-xs font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
          Dealer
        </span>
      );
    }
    if (lower.includes('hmsi')) {
      return (
        <span className="inline-flex items-center text-xs font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
          HMSI
        </span>
      );
    }
    return (
      <span className="inline-flex items-center text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
        HMMI / HML
      </span>
    );
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
      {/* Table Toolbar */}
      <div className="p-4 sm:p-5 border-b border-slate-200 bg-slate-50/50">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          
          {/* Search Input Box */}
          <div className="relative flex-1 max-w-lg">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Cari DTR, Part, No. Chassis, No. Engine, Dealer, QPI, Pemilik..."
              className="w-full pl-9 pr-9 py-2 text-xs sm:text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500 placeholder-slate-400 text-slate-900 transition-colors"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Quick Filter Controls */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Dealer Filter Dropdown */}
            <select
              value={selectedDealer}
              onChange={(e) => {
                setSelectedDealer(e.target.value);
                setCurrentPage(1);
              }}
              className="px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg text-slate-700 focus:outline-none focus:ring-1 focus:ring-red-500"
            >
              <option value="all">Semua Dealer ({dealersList.length})</option>
              {dealersList.map((dealer) => (
                <option key={dealer} value={dealer}>
                  {dealer}
                </option>
              ))}
            </select>

            {/* Stage Segmented Control */}
            <div className="flex items-center gap-1 bg-slate-200/80 p-0.5 rounded-lg text-xs font-medium">
              <button
                onClick={() => {
                  setActiveStageFilter('all');
                  setCurrentPage(1);
                }}
                className={`px-2.5 py-1.5 rounded-md transition-colors ${
                  activeStageFilter === 'all'
                    ? 'bg-white text-slate-900 font-semibold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Semua
              </button>
              <button
                onClick={() => {
                  setActiveStageFilter('dealer');
                  setCurrentPage(1);
                }}
                className={`px-2.5 py-1.5 rounded-md transition-colors ${
                  activeStageFilter === 'dealer'
                    ? 'bg-amber-600 text-white font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Dealer
              </button>
              <button
                onClick={() => {
                  setActiveStageFilter('hmsi');
                  setCurrentPage(1);
                }}
                className={`px-2.5 py-1.5 rounded-md transition-colors ${
                  activeStageFilter === 'hmsi'
                    ? 'bg-blue-600 text-white font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                HMSI
              </button>
              <button
                onClick={() => {
                  setActiveStageFilter('hmmi_hml');
                  setCurrentPage(1);
                }}
                className={`px-2.5 py-1.5 rounded-md transition-colors ${
                  activeStageFilter === 'hmmi_hml'
                    ? 'bg-emerald-600 text-white font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                HMMI/HML
              </button>
            </div>

            {/* Clear All Filters */}
            {(searchTerm || selectedDealer !== 'all' || activeStageFilter !== 'all') && (
              <button
                onClick={() => {
                  setSearchTerm('');
                  setSelectedDealer('all');
                  setActiveStageFilter('all');
                  setCurrentPage(1);
                }}
                className="px-2.5 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              >
                Reset Filter
              </button>
            )}
          </div>
        </div>

        {/* Filter Summary */}
        <div className="mt-3 flex items-center justify-between text-xs text-slate-500">
          <div>
            Menampilkan <strong className="text-slate-800 font-mono tabular-nums">{filteredRecords.length}</strong> data klaim OPF
            {searchTerm && <span> untuk kata kunci &ldquo;{searchTerm}&rdquo;</span>}
          </div>
          <div className="text-[11px] text-slate-400">
            Klik baris untuk melihat rincian klaim &amp; timeline alur
          </div>
        </div>
      </div>

      {/* Table Container */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="bg-slate-100/80 border-b border-slate-200 text-slate-700 font-semibold uppercase tracking-wider text-[11px]">
              <th className="py-3 px-4 whitespace-nowrap">No. DTR</th>
              <th className="py-3 px-4 whitespace-nowrap">Part Name (OPF)</th>
              <th className="py-3 px-3 text-center whitespace-nowrap">Qty</th>
              <th className="py-3 px-4 whitespace-nowrap">Model Unit</th>
              <th className="py-3 px-4 whitespace-nowrap font-mono">No. Chassis (Ch)</th>
              <th className="py-3 px-4 whitespace-nowrap font-mono">No. Engine (EG)</th>
              <th className="py-3 px-3 text-right whitespace-nowrap">Mileage</th>
              <th className="py-3 px-4 whitespace-nowrap">Dealer Name</th>
              <th className="py-3 px-3 whitespace-nowrap">Judgement Date</th>
              <th className="py-3 px-4 whitespace-nowrap">Judgement QPI</th>
              <th className="py-3 px-4 whitespace-nowrap">Nama Pemilik</th>
              <th className="py-3 px-3 whitespace-nowrap text-center">Status Alur</th>
              <th className="py-3 px-3 whitespace-nowrap text-right">Aksi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {isLoading ? (
              // Loading skeletons
              Array.from({ length: 5 }).map((_, i) => (
                <tr key={i} className="animate-pulse">
                  <td colSpan={13} className="py-4 px-4">
                    <div className="h-4 bg-slate-200 rounded w-full"></div>
                  </td>
                </tr>
              ))
            ) : paginatedRecords.length > 0 ? (
              paginatedRecords.map((item) => (
                <tr
                  key={item.id || item.dtr_number}
                  onClick={() => onSelectRecord(item)}
                  className="hover:bg-slate-50/80 cursor-pointer transition-colors group"
                >
                  {/* Nomor DTR */}
                  <td className="py-3 px-4 whitespace-nowrap font-mono font-bold text-red-600 group-hover:text-red-700">
                    {item.dtr_number}
                  </td>

                  {/* Part Name */}
                  <td className="py-3 px-4 font-semibold text-slate-900 whitespace-nowrap">
                    {item.part_name}
                  </td>

                  {/* Quantity */}
                  <td className="py-3 px-3 text-center font-mono font-bold text-slate-800">
                    {item.quantity}
                  </td>

                  {/* Model */}
                  <td className="py-3 px-4 text-slate-700 whitespace-nowrap">
                    {item.model}
                  </td>

                  {/* Chassis */}
                  <td className="py-3 px-4 font-mono text-slate-600 whitespace-nowrap">
                    {item.chassis_number}
                  </td>

                  {/* Engine */}
                  <td className="py-3 px-4 font-mono text-slate-600 whitespace-nowrap">
                    {item.engine_number}
                  </td>

                  {/* Mileage */}
                  <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-700 whitespace-nowrap">
                    {item.mileage ? `${item.mileage.toLocaleString('id-ID')} km` : '-'}
                  </td>

                  {/* Dealer */}
                  <td className="py-3 px-4 text-slate-700 whitespace-nowrap max-w-[200px] truncate" title={item.dealer_name}>
                    {item.dealer_name}
                  </td>

                  {/* Judgement Date */}
                  <td className="py-3 px-3 font-mono text-slate-600 whitespace-nowrap">
                    {item.judgement_date}
                  </td>

                  {/* Judgement QPI */}
                  <td className="py-3 px-4 whitespace-nowrap">
                    <span className="font-mono text-slate-800 font-medium">
                      {item.judgement_qpi}
                    </span>
                  </td>

                  {/* Nama Pemilik */}
                  <td className="py-3 px-4 text-slate-700 whitespace-nowrap max-w-[160px] truncate" title={item.owner_name}>
                    {item.owner_name}
                  </td>

                  {/* Status Alur */}
                  <td className="py-3 px-3 text-center whitespace-nowrap">
                    {handleStageBadge(item.status_stage)}
                  </td>

                  {/* Aksi */}
                  <td className="py-3 px-3 text-right whitespace-nowrap">
                    <div className="flex items-center justify-end gap-1.5" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => onSelectRecord(item)}
                        className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded"
                        title="Lihat Detail & Timeline Alur"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      {item.id && (
                        <button
                          onClick={() => {
                            if (window.confirm(`Hapus data klaim ${item.dtr_number}?`)) {
                              onDeleteRecord(item.id!);
                            }
                          }}
                          className="p-1 text-slate-300 hover:text-red-600 hover:bg-red-50 rounded"
                          title="Hapus Rekord"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={13} className="py-12 text-center text-slate-500">
                  <div className="max-w-sm mx-auto space-y-2">
                    <p className="font-semibold text-slate-700">Tidak ada data klaim OPF yang cocok.</p>
                    <p className="text-xs text-slate-400">
                      Coba ubah kata kunci pencarian atau reset filter alur pengerjaan.
                    </p>
                    <button
                      onClick={() => {
                        setSearchTerm('');
                        setSelectedDealer('all');
                        setActiveStageFilter('all');
                      }}
                      className="mt-2 px-3 py-1.5 text-xs font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800"
                    >
                      Tampilkan Semua Data
                    </button>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="p-4 border-t border-slate-200 bg-slate-50 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600">
        <div className="flex items-center gap-2">
          <span>Baris per halaman:</span>
          <select
            value={itemsPerPage}
            onChange={(e) => {
              setItemsPerPage(Number(e.target.value));
              setCurrentPage(1);
            }}
            className="px-2 py-1 bg-white border border-slate-300 rounded text-xs font-mono"
          >
            <option value={10}>10</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
          </select>
          <span className="text-slate-400">·</span>
          <span>
            Halaman <strong className="font-mono">{currentPage}</strong> dari{' '}
            <strong className="font-mono">{totalPages}</strong>
          </span>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))}
            disabled={currentPage === 1}
            className={`p-1.5 rounded border border-slate-300 bg-white ${
              currentPage === 1
                ? 'opacity-40 cursor-not-allowed text-slate-300'
                : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="px-3 font-mono text-xs">
            {currentPage} / {totalPages}
          </span>
          <button
            onClick={() => setCurrentPage((p) => Math.min(p + 1, totalPages))}
            disabled={currentPage === totalPages}
            className={`p-1.5 rounded border border-slate-300 bg-white ${
              currentPage === totalPages
                ? 'opacity-40 cursor-not-allowed text-slate-300'
                : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
