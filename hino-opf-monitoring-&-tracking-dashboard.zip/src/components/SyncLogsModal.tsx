import React from 'react';
import { X, Activity, CheckCircle2, AlertTriangle, Clock, RefreshCw, Cpu } from 'lucide-react';
import { SyncLog, SyncStatus } from '../types';

interface SyncLogsModalProps {
  isOpen: boolean;
  onClose: () => void;
  logs: SyncLog[];
  status: SyncStatus | null;
  onTriggerSync: () => void;
  isSyncing: boolean;
}

export const SyncLogsModal: React.FC<SyncLogsModalProps> = ({
  isOpen,
  onClose,
  logs,
  status,
  onTriggerSync,
  isSyncing,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Cpu className="w-5 h-5 text-red-500" />
            <div>
              <h3 className="font-bold text-sm sm:text-base">
                Status &amp; Log Robot Penarik Data HIS
              </h3>
              <p className="text-xs text-slate-400">
                Automated Headless Crawler &amp; SQLite Storage Monitor
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Status Banner */}
        <div className="p-5 bg-slate-50 border-b border-slate-200">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            
            <div className="bg-white p-3 rounded-lg border border-slate-200">
              <span className="text-slate-500 block text-[11px]">Kondisi Robot</span>
              <span className="font-bold text-slate-900 flex items-center gap-1.5 mt-0.5">
                <span className={`w-2 h-2 rounded-full ${status?.isRunning ? 'bg-amber-500 animate-ping' : 'bg-emerald-500'}`} />
                {status?.isRunning ? 'Sedang Bekerja' : 'Siap / Standby'}
              </span>
            </div>

            <div className="bg-white p-3 rounded-lg border border-slate-200">
              <span className="text-slate-500 block text-[11px]">Siklus Otomatis</span>
              <span className="font-mono font-bold text-slate-900 mt-0.5 block">
                Tiap 3 Jam
              </span>
            </div>

            <div className="bg-white p-3 rounded-lg border border-slate-200">
              <span className="text-slate-500 block text-[11px]">Total Ditarik</span>
              <span className="font-mono font-bold text-red-600 mt-0.5 block">
                {status?.totalSyncedCount || 0} Record
              </span>
            </div>

            <div className="bg-white p-3 rounded-lg border border-slate-200">
              <span className="text-slate-500 block text-[11px]">Jadwal Berikutnya</span>
              <span className="font-mono text-slate-700 text-[11px] truncate block mt-0.5">
                {status?.nextScheduledRun ? new Date(status.nextScheduledRun).toLocaleTimeString('id-ID') : 'Dalam 3 Jam'}
              </span>
            </div>

          </div>

          <div className="mt-3 text-xs text-slate-600 bg-white p-3 rounded-lg border border-slate-200">
            <span className="font-semibold text-slate-800">Catatan Eksekusi Terakhir: </span>
            <span>{status?.lastRunMessage || 'Robot standby menunggu giliran penarikan.'}</span>
          </div>

          <div className="mt-3 flex items-center justify-end">
            <button
              onClick={onTriggerSync}
              disabled={isSyncing}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-red-600 text-white text-xs font-semibold rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{isSyncing ? 'Menarik Data...' : 'Jalankan Robot Sekarang'}</span>
            </button>
          </div>
        </div>

        {/* Log Entries List */}
        <div className="p-6 overflow-y-auto space-y-3 text-xs">
          <h4 className="font-bold text-slate-900 uppercase tracking-wider text-[11px]">
            Riwayat Penarikan Data (Audit Trail)
          </h4>

          {logs.length > 0 ? (
            <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
              {logs.map((log) => (
                <div key={log.id || log.timestamp} className="p-3 bg-white hover:bg-slate-50 flex items-start gap-3">
                  <div className="mt-0.5">
                    {log.status === 'success' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-red-600" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-semibold text-slate-900">
                        {log.status === 'success' ? 'Sukses Sinkronisasi' : 'Gagal Sinkronisasi'}
                      </span>
                      <span className="font-mono text-[11px] text-slate-400">
                        {new Date(log.timestamp).toLocaleString('id-ID')}
                      </span>
                    </div>
                    <p className="text-slate-600 text-xs mt-0.5 break-words">
                      {log.message}
                    </p>
                    <div className="mt-1 flex items-center gap-3 text-[11px] text-slate-400 font-mono">
                      <span>Ditarik: {log.records_extracted}</span>
                      <span>Baru: {log.records_new}</span>
                      <span>Durasi: {log.duration_ms} ms</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-slate-400 text-center py-6">
              Belum ada riwayat aktivitas penarikan data yang tercatat.
            </p>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>Penyimpanan: SQLite file <code className="font-mono">/data/opf_database.sqlite</code></span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-white border border-slate-300 text-slate-700 font-medium rounded-lg hover:bg-slate-50"
          >
            Tutup
          </button>
        </div>

      </div>
    </div>
  );
};
