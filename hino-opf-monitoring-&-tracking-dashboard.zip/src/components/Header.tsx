import React from 'react';
import { RefreshCw, Plus, Download, BookOpen, Clock, Activity } from 'lucide-react';
import { SyncStatus } from '../types';

interface HeaderProps {
  onSync: () => void;
  isSyncing: boolean;
  syncStatus: SyncStatus | null;
  onOpenManualEntry: () => void;
  onOpenGuide: () => void;
  onOpenSyncLogs: () => void;
  activeTab: 'all' | 'dealer' | 'hmsi' | 'hmmi_hml';
  setActiveTab: (tab: 'all' | 'dealer' | 'hmsi' | 'hmmi_hml') => void;
}

export const Header: React.FC<HeaderProps> = ({
  onSync,
  isSyncing,
  syncStatus,
  onOpenManualEntry,
  onOpenGuide,
  onOpenSyncLogs,
  activeTab,
  setActiveTab,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      {/* Top Bar Contract: 3 zones separated cleanly */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-6">
        
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-9 h-9 rounded-lg bg-red-600 flex items-center justify-center text-white font-black tracking-tighter text-lg shadow-sm">
            H
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-base font-extrabold tracking-tight text-slate-900 whitespace-nowrap">
                HINO OPF TRACKER
              </span>
              <span className="text-[11px] font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded text-center whitespace-nowrap">
                HIS Gateway
              </span>
            </div>
            <p className="text-xs text-slate-500 hidden sm:block">
              Dealer &rarr; HMSI &rarr; HMMI/HML Workflow Monitor
            </p>
          </div>
        </div>

        {/* Zone 2: Navigation / Stage Quick Filter */}
        <nav className="hidden md:flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'all'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Semua Data
          </button>
          <button
            onClick={() => setActiveTab('dealer')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'dealer'
                ? 'bg-white text-amber-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Draft / Dealer
          </button>
          <button
            onClick={() => setActiveTab('hmsi')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'hmsi'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Processed / HMSI
          </button>
          <button
            onClick={() => setActiveTab('hmmi_hml')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
              activeTab === 'hmmi_hml'
                ? 'bg-white text-emerald-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Completed / HMMI-HML
          </button>
        </nav>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Guide Modal Trigger */}
          <button
            onClick={onOpenGuide}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap"
            title="Panduan Deploy Render.com"
          >
            <BookOpen className="w-3.5 h-3.5 text-slate-500" />
            <span className="hidden sm:inline">Panduan Deploy</span>
          </button>

          {/* Sync History / Robot Logs */}
          <button
            onClick={onOpenSyncLogs}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap"
            title="Status & Log Robot HIS"
          >
            <Activity className="w-3.5 h-3.5 text-slate-500" />
            <span className="hidden lg:inline">Log Robot</span>
          </button>

          {/* Manual Entry */}
          <button
            onClick={onOpenManualEntry}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap"
            title="Tambah Data DTR Manual"
          >
            <Plus className="w-3.5 h-3.5 text-slate-700" />
            <span className="hidden sm:inline">Input DTR</span>
          </button>

          {/* Export CSV */}
          <a
            href="/api/export/csv"
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap"
            title="Unduh data dalam format CSV untuk Excel"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span className="hidden xl:inline">Export CSV</span>
          </a>

          {/* Sync HIS Scraper Button */}
          <button
            onClick={onSync}
            disabled={isSyncing}
            className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-white rounded-lg transition-all shadow-xs whitespace-nowrap ${
              isSyncing
                ? 'bg-red-400 cursor-not-allowed'
                : 'bg-red-600 hover:bg-red-700 active:scale-95'
            }`}
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'Menarik Data...' : 'Tarik Data HIS'}</span>
          </button>
        </div>

      </div>

      {/* Sub-bar for mobile filters and sync notification banner */}
      <div className="md:hidden border-t border-slate-200 bg-slate-50 px-4 py-2 flex items-center justify-between overflow-x-auto gap-2">
        <span className="text-xs text-slate-500 shrink-0">Filter Alur:</span>
        <div className="flex items-center gap-1 shrink-0">
          {(['all', 'dealer', 'hmsi', 'hmmi_hml'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-2 py-1 text-xs font-medium rounded ${
                activeTab === tab
                  ? 'bg-slate-900 text-white'
                  : 'bg-white text-slate-600 border border-slate-200'
              }`}
            >
              {tab === 'all'
                ? 'Semua'
                : tab === 'dealer'
                ? 'Dealer'
                : tab === 'hmsi'
                ? 'HMSI'
                : 'HMMI/HML'}
            </button>
          ))}
        </div>
      </div>
    </header>
  );
};
