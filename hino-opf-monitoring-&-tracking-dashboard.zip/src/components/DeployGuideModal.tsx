import React, { useState } from 'react';
import {
  X,
  BookOpen,
  Copy,
  Check,
  ExternalLink,
  Shield,
  Server,
  Cloud,
  Layers,
  ArrowRight
} from 'lucide-react';

interface DeployGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DeployGuideModal: React.FC<DeployGuideModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [activeStep, setActiveStep] = useState<number>(1);

  const copyToClipboard = (text: string, keyName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(keyName);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-3xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-red-600 flex items-center justify-center font-bold text-white">
              <Cloud className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base">
                Panduan Deploy Pemula: Pasang ke Render.com Gratis
              </h3>
              <p className="text-xs text-slate-400">
                100% Lewat Browser Web, Tanpa Perlu Coding atau Menguasai Terminal
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Step Tabs */}
        <div className="flex border-b border-slate-200 bg-slate-50 text-xs font-semibold overflow-x-auto">
          {[
            { num: 1, label: '1. Upload ke GitHub' },
            { num: 2, label: '2. Hubungkan Render' },
            { num: 3, label: '3. Input Password HIS' },
            { num: 4, label: '4. Selesai & Aktif' },
          ].map((tab) => (
            <button
              key={tab.num}
              onClick={() => setActiveStep(tab.num)}
              className={`px-4 py-3 border-b-2 whitespace-nowrap transition-colors flex items-center gap-2 ${
                activeStep === tab.num
                  ? 'border-red-600 text-red-600 bg-white'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Content Area */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs sm:text-sm text-slate-700">
          
          {/* STEP 1: GITHUB */}
          {activeStep === 1 && (
            <div className="space-y-4">
              <div className="bg-red-50 border border-red-200 rounded-xl p-4">
                <h4 className="font-bold text-red-900 text-sm mb-1">
                  Langkah 1: Masukkan Seluruh Kode ke GitHub (Cukup Drag &amp; Drop)
                </h4>
                <p className="text-xs text-red-700">
                  Anda tidak perlu menggunakan perintah git atau command line di komputer Anda.
                </p>
              </div>

              <ol className="list-decimal list-inside space-y-3 pl-1">
                <li>
                  Buka website <a href="https://github.com" target="_blank" rel="noreferrer" className="text-red-600 font-bold underline inline-flex items-center gap-0.5">github.com <ExternalLink className="w-3 h-3" /></a> dan pastikan Anda sudah login (bisa daftar gratis).
                </li>
                <li>
                  Klik tombol <strong>&ldquo;New&rdquo;</strong> (atau tanda <strong>+</strong> di pojok kanan atas &rarr; pilih <em>New repository</em>).
                </li>
                <li>
                  Beri nama repositori Anda: <code className="bg-slate-100 px-2 py-0.5 rounded font-mono font-bold text-red-600">hino-opf-monitoring</code>.
                </li>
                <li>
                  Pilih opsi <strong>Private</strong> (agar kode dan data Anda tidak bisa dilihat publik) lalu klik tombol hijau <strong>&ldquo;Create repository&rdquo;</strong>.
                </li>
                <li>
                  Di halaman baru yang terbuka, klik link biru bertuliskan <strong>&ldquo;uploading an existing file&rdquo;</strong>.
                </li>
                <li>
                  Buka folder proyek ini di komputer Anda, lalu <strong>Drag &amp; Drop (seret semua file)</strong> ke jendela browser GitHub tersebut (pastikan file <code>Dockerfile</code>, <code>server.ts</code>, <code>package.json</code>, dan folder <code>src</code> ter-upload).
                </li>
                <li>
                  Klik tombol hijau <strong>&ldquo;Commit changes&rdquo;</strong> di bawah. File Anda sekarang sudah tersimpan aman di GitHub!
                </li>
              </ol>
            </div>
          )}

          {/* STEP 2: RENDER */}
          {activeStep === 2 && (
            <div className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                <h4 className="font-bold text-blue-900 text-sm mb-1">
                  Langkah 2: Sambungkan Repositori GitHub ke Render.com
                </h4>
                <p className="text-xs text-blue-700">
                  Render.com menyediakan hosting gratis 24 jam dengan dukungan Docker Linux untuk robot Chromium.
                </p>
              </div>

              <ol className="list-decimal list-inside space-y-3 pl-1">
                <li>
                  Buka <a href="https://render.com" target="_blank" rel="noreferrer" className="text-blue-600 font-bold underline inline-flex items-center gap-0.5">render.com <ExternalLink className="w-3 h-3" /></a> dan login menggunakan akun GitHub Anda.
                </li>
                <li>
                  Di halaman dashboard Render, klik tombol <strong>&ldquo;New +&rdquo;</strong> di kanan atas, lalu pilih <strong>&ldquo;Web Service&rdquo;</strong>.
                </li>
                <li>
                  Pilih opsi <strong>&ldquo;Build and deploy from a Git repository&rdquo;</strong> &rarr; klik <strong>Next</strong>.
                </li>
                <li>
                  Cari repositori Anda <code className="bg-slate-100 px-1.5 py-0.5 rounded font-mono">hino-opf-monitoring</code> lalu klik tombol <strong>&ldquo;Connect&rdquo;</strong>.
                </li>
                <li>
                  Isi formulir Web Service:
                  <ul className="list-disc list-inside mt-2 space-y-1 pl-4 text-slate-600">
                    <li><strong>Name</strong>: contoh <code className="font-mono text-slate-800">hino-tracker-live</code></li>
                    <li><strong>Region</strong>: pilih <strong>Singapore (Southeast Asia)</strong> untuk kecepatan terbaik dari Indonesia</li>
                    <li><strong>Runtime</strong>: Render otomatis memilih <strong>Docker</strong> (karena sudah ada file <code>Dockerfile</code> bawaan kami)</li>
                    <li><strong>Instance Type</strong>: pilih <strong>Free ($0 / bulan)</strong></li>
                  </ul>
                </li>
              </ol>
            </div>
          )}

          {/* STEP 3: ENVIRONMENT VARIABLES */}
          {activeStep === 3 && (
            <div className="space-y-4">
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
                <h4 className="font-bold text-amber-900 text-sm mb-1">
                  Langkah 3: Masukkan Kredensial Akun HIS Hino Anda
                </h4>
                <p className="text-xs text-amber-700">
                  Username dan Password disimpan di brankas terenkripsi Render agar tidak terlihat di kode publik.
                </p>
              </div>

              <p className="text-xs text-slate-600">
                Pada halaman formulir Render yang sama, gulir ke bagian <strong>&ldquo;Environment Variables&rdquo;</strong> dan klik <strong>&ldquo;Add Environment Variable&rdquo;</strong> untuk memasukkan 3 variabel ini:
              </p>

              <div className="space-y-2.5">
                {/* Var 1 */}
                <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200 rounded-lg">
                  <div>
                    <span className="block font-mono font-bold text-slate-900 text-xs">HIS_USER</span>
                    <span className="text-[11px] text-slate-500">Username login portal HIS Hino Anda</span>
                  </div>
                  <button
                    onClick={() => copyToClipboard('HIS_USER', 'HIS_USER')}
                    className="flex items-center gap-1 px-2.5 py-1 text-xs bg-white border border-slate-300 rounded hover:bg-slate-50"
                  >
                    {copiedKey === 'HIS_USER' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>Salin Key</span>
                  </button>
                </div>

                {/* Var 2 */}
                <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200 rounded-lg">
                  <div>
                    <span className="block font-mono font-bold text-slate-900 text-xs">HIS_PASSWORD</span>
                    <span className="text-[11px] text-slate-500">Password akun portal HIS Hino Anda</span>
                  </div>
                  <button
                    onClick={() => copyToClipboard('HIS_PASSWORD', 'HIS_PASSWORD')}
                    className="flex items-center gap-1 px-2.5 py-1 text-xs bg-white border border-slate-300 rounded hover:bg-slate-50"
                  >
                    {copiedKey === 'HIS_PASSWORD' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>Salin Key</span>
                  </button>
                </div>

                {/* Var 3 */}
                <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200 rounded-lg">
                  <div>
                    <span className="block font-mono font-bold text-slate-900 text-xs">SYNC_INTERVAL_HOURS</span>
                    <span className="text-[11px] text-slate-500">Interval robot otomatis (isi: 3)</span>
                  </div>
                  <button
                    onClick={() => copyToClipboard('3', 'SYNC_INTERVAL_HOURS')}
                    className="flex items-center gap-1 px-2.5 py-1 text-xs bg-white border border-slate-300 rounded hover:bg-slate-50"
                  >
                    {copiedKey === 'SYNC_INTERVAL_HOURS' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>Salin &quot;3&quot;</span>
                  </button>
                </div>
              </div>

              <div className="p-3 bg-slate-100 rounded-lg text-xs text-slate-600 flex items-start gap-2">
                <Shield className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>
                  Sistem keamanan berlapis menjamin kredensial HIS Anda tidak akan pernah bocor ke publik atau browser client.
                </span>
              </div>
            </div>
          )}

          {/* STEP 4: SELESAI */}
          {activeStep === 4 && (
            <div className="space-y-4">
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 text-center">
                <div className="w-12 h-12 mx-auto rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mb-2">
                  <Check className="w-6 h-6" />
                </div>
                <h4 className="font-bold text-emerald-900 text-base">
                  Klik &ldquo;Create Web Service&rdquo; &amp; Dashboard Siap Digunakan!
                </h4>
                <p className="text-xs text-emerald-700 mt-1 max-w-md mx-auto">
                  Render akan otomatis merakit container Docker, memasang Chromium Linux, menyalakan database SQLite, dan mengaktifkan robot otomatis setiap 3 jam.
                </p>
              </div>

              <div className="space-y-2 text-xs">
                <p className="font-semibold text-slate-800">Apa yang terjadi setelah Anda klik Create?</p>
                <ul className="list-disc list-inside space-y-1.5 text-slate-600 pl-2">
                  <li>Tunggu sekitar 3–5 menit hingga indikator status di Render berubah menjadi hijau <strong>&ldquo;Live&rdquo;</strong>.</li>
                  <li>Di bagian atas layar Render, akan muncul tautan website Anda (contoh: <code className="font-mono text-red-600">https://hino-tracker-live.onrender.com</code>).</li>
                  <li>Buka tautan tersebut dari HP maupun Laptop kapan saja, di mana saja!</li>
                  <li>Data histori tersimpan aman di database SQLite berbasis file tanpa perlu biaya server bulanan.</li>
                </ul>
              </div>
            </div>
          )}

        </div>

        {/* Footer Navigation */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs">
          <button
            onClick={() => setActiveStep((s) => Math.max(s - 1, 1))}
            disabled={activeStep === 1}
            className={`px-3 py-1.5 rounded-lg border border-slate-300 font-medium ${
              activeStep === 1 ? 'opacity-40 cursor-not-allowed' : 'hover:bg-slate-100 text-slate-700'
            }`}
          >
            Kembali
          </button>

          <div className="text-slate-500 font-medium">
            Langkah {activeStep} dari 4
          </div>

          {activeStep < 4 ? (
            <button
              onClick={() => setActiveStep((s) => Math.min(s + 1, 4))}
              className="px-4 py-1.5 rounded-lg bg-red-600 text-white font-semibold hover:bg-red-700 flex items-center gap-1"
            >
              <span>Lanjut</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-slate-900 text-white font-semibold hover:bg-slate-800"
            >
              Tutup Panduan
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
