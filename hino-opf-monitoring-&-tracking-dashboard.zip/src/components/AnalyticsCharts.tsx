import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from 'chart.js';
import { Bar, Doughnut } from 'react-chartjs-2';
import { StatsData } from '../types';
import { AlertTriangle, PieChart, Layers } from 'lucide-react';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

interface AnalyticsChartsProps {
  stats: StatsData | null;
  onFilterByPart: (partName: string) => void;
  onFilterByModel: (modelName: string) => void;
}

export const AnalyticsCharts: React.FC<AnalyticsChartsProps> = ({
  stats,
  onFilterByPart,
  onFilterByModel,
}) => {
  const topParts = stats?.topParts || [];
  const modelDist = stats?.modelDistribution || [];

  // Bar chart data for Top 5/6 OPF Parts
  const barChartData = {
    labels: topParts.map((p) => p.name),
    datasets: [
      {
        label: 'Frekuensi / Qty Rusak',
        data: topParts.map((p) => p.count),
        backgroundColor: [
          'rgba(220, 38, 38, 0.85)', // Hino red
          'rgba(234, 88, 12, 0.85)', // Orange
          'rgba(217, 119, 6, 0.85)', // Amber
          'rgba(37, 99, 235, 0.85)', // Blue
          'rgba(79, 70, 229, 0.85)', // Indigo
          'rgba(107, 114, 128, 0.85)', // Gray
        ],
        borderRadius: 6,
        borderWidth: 0,
        maxBarThickness: 36,
      },
    ],
  };

  const barChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: (context: any) => ` Total Kerusakan: ${context.raw} unit part`,
        },
      },
    },
    scales: {
      x: {
        grid: {
          display: false,
        },
        ticks: {
          font: {
            size: 11,
          },
          maxRotation: 25,
          minRotation: 0,
          callback: function (_val: any, index: number) {
            const label = topParts[index]?.name || '';
            return label.length > 18 ? label.substring(0, 16) + '...' : label;
          },
        },
      },
      y: {
        beginAtZero: true,
        ticks: {
          stepSize: 1,
          font: {
            size: 11,
          },
        },
        grid: {
          color: 'rgba(0, 0, 0, 0.05)',
        },
      },
    },
    onClick: (_event: any, elements: any[]) => {
      if (elements.length > 0) {
        const index = elements[0].index;
        const part = topParts[index]?.name;
        if (part) {
          onFilterByPart(part);
        }
      }
    },
  };

  // Doughnut chart for Model distribution
  const doughnutData = {
    labels: modelDist.map((m) => m.model),
    datasets: [
      {
        data: modelDist.map((m) => m.count),
        backgroundColor: [
          '#DC2626', // Hino Red
          '#2563EB', // Blue
          '#D97706', // Amber
          '#10B981', // Emerald
          '#6B7280', // Gray
        ],
        borderWidth: 2,
        borderColor: '#FFFFFF',
      },
    ],
  };

  const doughnutOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          boxWidth: 12,
          padding: 12,
          font: {
            size: 11,
          },
        },
      },
    },
    onClick: (_event: any, elements: any[]) => {
      if (elements.length > 0) {
        const index = elements[0].index;
        const model = modelDist[index]?.model;
        if (model) {
          onFilterByModel(model);
        }
      }
    },
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Top 5 OPF Components Bar Chart */}
      <div className="lg:col-span-2 bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-red-50 text-red-600 flex items-center justify-center">
                <AlertTriangle className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Top 5 Komponen Sering Rusak (Top OPF Part Failure)
                </h3>
                <p className="text-xs text-slate-500">
                  Berdasarkan akumulasi kuantitas part gagal pada klaim garansi
                </p>
              </div>
            </div>
            <span className="text-xs text-slate-400 font-mono hidden sm:inline">
              Klik bar untuk filter
            </span>
          </div>

          <div className="h-64 mt-4 relative">
            {topParts.length > 0 ? (
              <Bar data={barChartData} options={barChartOptions} />
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-slate-400">
                Data OPF belum tersedia untuk ditampilkan.
              </div>
            )}
          </div>
        </div>

        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap gap-2 text-xs text-slate-600">
          <span className="font-semibold text-slate-800">Prioritas Investigasi:</span>
          {topParts.slice(0, 3).map((item, idx) => (
            <button
              key={idx}
              onClick={() => onFilterByPart(item.name)}
              className="text-red-700 hover:text-red-900 hover:underline bg-red-50/80 px-2 py-0.5 rounded text-[11px] font-medium"
            >
              #{idx + 1} {item.name} ({item.count} unit)
            </button>
          ))}
        </div>
      </div>

      {/* Model Distribution Doughnut Chart */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
                <PieChart className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">Sebaran Model Kendaraan</h3>
                <p className="text-xs text-slate-500">Proporsi klaim per tipe unit Hino</p>
              </div>
            </div>
          </div>

          <div className="h-64 mt-4 relative">
            {modelDist.length > 0 ? (
              <Doughnut data={doughnutData} options={doughnutOptions} />
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-slate-400">
                Belum ada data distribusi model.
              </div>
            )}
          </div>
        </div>

        <div className="mt-4 pt-3 border-t border-slate-100 text-[11px] text-slate-500 flex items-center justify-between">
          <span>Kategori: Heavy Duty 500 & Light Duty Dutro</span>
          <span className="font-mono tabular-nums">{modelDist.length} Varian</span>
        </div>
      </div>
    </div>
  );
};
