import React from 'react';
import { ArrowRight, FileText, CheckCircle2, Building, Wrench, ShieldCheck, ChevronRight } from 'lucide-react';
import { StatsData } from '../types';

interface WorkflowTrackerCardsProps {
  stats: StatsData | null;
  activeTab: 'all' | 'dealer' | 'hmsi' | 'hmmi_hml';
  onSelectTab: (tab: 'all' | 'dealer' | 'hmsi' | 'hmmi_hml') => void;
}

export const WorkflowTrackerCards: React.FC<WorkflowTrackerCardsProps> = ({
  stats,
  activeTab,
  onSelectTab,
}) => {
  const total = stats?.totalRecords || 0;
  const dealerCount = stats?.stageCounts.dealer || 0;
  const hmsiCount = stats?.stageCounts.hmsi || 0;
  const hmmiCount = stats?.stageCounts.hmmi_hml || 0;

  const dealerPct = total > 0 ? Math.round((dealerCount / total) * 100) : 0;
  const hmsiPct = total > 0 ? Math.round((hmsiCount / total) * 100) : 0;
  const hmmiPct = total > 0 ? Math.round((hmmiCount / total) * 100) : 0;

  return (
    <div className="space-y-4">
      {/* Workflow Stage Visualizer Stepper Header */}
      <div className="bg-slate-900 text-white rounded-xl p-5 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-red-400">
              <span className="w-2 h-2 rounded-full bg-red-500"></span>
              <span>ALUR KLAIM OPF (ORIGINAL PART FAILURE)</span>
            </div>
            <h2 className="text-xl font-bold tracking-tight text-white mt-1">
              Monitoring Siklus Klaim Kerusakan Part Garansi Hino
            </h2>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl">
              Memantau investigasi teknis secara transparan: input di Bengkel Resmi Dealer, verifikasi teknis HMSI, hingga keputusan final pabrik manufaktur HMMI/HML.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0 bg-slate-800/80 px-4 py-2.5 rounded-lg border border-slate-700">
            <div>
              <span className="block text-[11px] text-slate-400 font-medium">Total Klaim OPF</span>
              <span className="text-2xl font-extrabold text-white font-mono tabular-nums">
                {total}
              </span>
            </div>
            <div className="h-8 w-px bg-slate-700"></div>
            <div>
              <span className="block text-[11px] text-emerald-400 font-medium">Tingkat Selesai</span>
              <span className="text-2xl font-extrabold text-emerald-400 font-mono tabular-nums">
                {hmmiPct}%
              </span>
            </div>
          </div>
        </div>

        {/* Linear Stage Flow Bar */}
        <div className="mt-5 grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* Step 1: Dealer */}
          <div className="flex items-center gap-3 bg-slate-800/50 p-3 rounded-lg border border-slate-700/60">
            <div className="w-8 h-8 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs shrink-0">
              01
            </div>
            <div className="min-w-0">
              <span className="block text-xs font-bold text-amber-300">Tahap 1: Dealer Resmi</span>
              <span className="text-[11px] text-slate-400 truncate block">Penerbitan DTR & Tagging Part</span>
            </div>
            <ArrowRight className="w-4 h-4 text-slate-600 ml-auto hidden md:block shrink-0" />
          </div>

          {/* Step 2: HMSI */}
          <div className="flex items-center gap-3 bg-slate-800/50 p-3 rounded-lg border border-slate-700/60">
            <div className="w-8 h-8 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-xs shrink-0">
              02
            </div>
            <div className="min-w-0">
              <span className="block text-xs font-bold text-blue-300">Tahap 2: Distributor HMSI</span>
              <span className="text-[11px] text-slate-400 truncate block">Screening & Technical Lab Review</span>
            </div>
            <ArrowRight className="w-4 h-4 text-slate-600 ml-auto hidden md:block shrink-0" />
          </div>

          {/* Step 3: HMMI/HML */}
          <div className="flex items-center gap-3 bg-slate-800/50 p-3 rounded-lg border border-slate-700/60">
            <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs shrink-0">
              03
            </div>
            <div className="min-w-0">
              <span className="block text-xs font-bold text-emerald-300">Tahap 3: HMMI / HML</span>
              <span className="text-[11px] text-slate-400 truncate block">Factory QA Judgement & Reimburse</span>
            </div>
            <CheckCircle2 className="w-4 h-4 text-emerald-500 ml-auto hidden md:block shrink-0" />
          </div>
        </div>
      </div>

      {/* 3 Interactive Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* Card 1: Draft / Dealer */}
        <button
          onClick={() => onSelectTab(activeTab === 'dealer' ? 'all' : 'dealer')}
          className={`text-left p-5 rounded-xl border transition-all relative overflow-hidden bg-white ${
            activeTab === 'dealer'
              ? 'border-amber-500 ring-2 ring-amber-500/20 shadow-md'
              : 'border-slate-200 hover:border-slate-300 hover:shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center">
                <Wrench className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Tahap 1</span>
                <span className="text-sm font-bold text-slate-900">Draft / Dealer</span>
              </div>
            </div>
            <span className="text-2xl font-extrabold text-amber-600 font-mono tabular-nums">
              {dealerCount}
            </span>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Porsi: <strong className="text-slate-800 font-mono">{dealerPct}%</strong> dari total</span>
            <span className="flex items-center gap-0.5 text-amber-700 font-medium">
              Filter stage <ChevronRight className="w-3.5 h-3.5" />
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-2 line-clamp-2">
            Klaim baru diajukan oleh jaringan bengkel resmi Hino. Menunggu kelengkapan dokumen teknis & tag identifikasi part.
          </p>
        </button>

        {/* Card 2: Processed / HMSI */}
        <button
          onClick={() => onSelectTab(activeTab === 'hmsi' ? 'all' : 'hmsi')}
          className={`text-left p-5 rounded-xl border transition-all relative overflow-hidden bg-white ${
            activeTab === 'hmsi'
              ? 'border-blue-500 ring-2 ring-blue-500/20 shadow-md'
              : 'border-slate-200 hover:border-slate-300 hover:shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center">
                <Building className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Tahap 2</span>
                <span className="text-sm font-bold text-slate-900">Processed / HMSI</span>
              </div>
            </div>
            <span className="text-2xl font-extrabold text-blue-600 font-mono tabular-nums">
              {hmsiCount}
            </span>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Porsi: <strong className="text-slate-800 font-mono">{hmsiPct}%</strong> dari total</span>
            <span className="flex items-center gap-0.5 text-blue-700 font-medium">
              Filter stage <ChevronRight className="w-3.5 h-3.5" />
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-2 line-clamp-2">
            Sedang ditelaah oleh tim Technical Service HMSI. Pemeriksaan spesifikasi operasional, kualitas bahan bakar & uji lab.
          </p>
        </button>

        {/* Card 3: Completed / HMMI - HML */}
        <button
          onClick={() => onSelectTab(activeTab === 'hmmi_hml' ? 'all' : 'hmmi_hml')}
          className={`text-left p-5 rounded-xl border transition-all relative overflow-hidden bg-white ${
            activeTab === 'hmmi_hml'
              ? 'border-emerald-500 ring-2 ring-emerald-500/20 shadow-md'
              : 'border-slate-200 hover:border-slate-300 hover:shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Tahap 3</span>
                <span className="text-sm font-bold text-slate-900">Completed / HMMI-HML</span>
              </div>
            </div>
            <span className="text-2xl font-extrabold text-emerald-600 font-mono tabular-nums">
              {hmmiCount}
            </span>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Porsi: <strong className="text-slate-800 font-mono">{hmmiPct}%</strong> dari total</span>
            <span className="flex items-center gap-0.5 text-emerald-700 font-medium">
              Filter stage <ChevronRight className="w-3.5 h-3.5" />
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-2 line-clamp-2">
            Putusan final QA Pabrik HMMI & Hino Motors Ltd. Jepang. Part pengganti disetujui dan garansi selesai dibayarkan.
          </p>
        </button>

      </div>
    </div>
  );
};
