import React, { useState } from 'react';
import {
  X,
  Truck,
  Wrench,
  Building,
  ShieldCheck,
  Calendar,
  User,
  CheckCircle2,
  Clock,
  AlertCircle,
  FileText,
  Printer
} from 'lucide-react';
import { OpfRecord } from '../types';

interface DetailModalProps {
  record: OpfRecord | null;
  onClose: () => void;
  onUpdateStatus?: (updated: OpfRecord) => void;
}

export const DetailModal: React.FC<DetailModalProps> = ({
  record,
  onClose,
  onUpdateStatus,
}) => {
  if (!record) return null;

  const [currentStage, setCurrentStage] = useState<'Dealer' | 'HMSI' | 'HMMI/HML'>(record.status_stage);
  const [detailStatus, setDetailStatus] = useState(record.status_detail);
  const [isUpdating, setIsUpdating] = useState(false);

  const getStageStep = (stage: string) => {
    const s = stage.toLowerCase();
    if (s.includes('dealer')) return 1;
    if (s.includes('hmsi')) return 2;
    return 3;
  };

  const activeStep = getStageStep(currentStage);

  const handleSaveStatus = async () => {
    if (!onUpdateStatus) return;
    setIsUpdating(true);
    try {
      const updated: OpfRecord = {
        ...record,
        status_stage: currentStage,
        status_detail: detailStatus,
      };
      await onUpdateStatus(updated);
    } finally {
      setIsUpdating(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6">
      <div className="bg-white rounded-2xl max-w-3xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-red-600 flex items-center justify-center font-bold text-white">
              H
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs font-semibold text-red-400">
                  {record.dtr_number}
                </span>
                <span className="text-[11px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded">
                  OPF Claim Detail
                </span>
              </div>
              <h2 className="text-base font-bold text-white truncate max-w-md">
                {record.part_name} ({record.quantity} unit)
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
              title="Cetak Lembar DTR"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs sm:text-sm">
          
          {/* Claim Progression Timeline */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
            <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">
              Alur Investigasi &amp; Putusan Garansi
            </h4>
            
            <div className="grid grid-cols-3 gap-2 relative">
              {/* Step 1: Dealer */}
              <div className={`p-3 rounded-lg border text-center transition-all ${
                activeStep >= 1 ? 'bg-amber-50 border-amber-300' : 'bg-white border-slate-200 opacity-60'
              }`}>
                <div className="w-7 h-7 mx-auto rounded-full bg-amber-500 text-white flex items-center justify-center text-xs font-bold mb-1.5">
                  1
                </div>
                <div className="font-bold text-slate-900 text-xs">Dealer Resmi</div>
                <div className="text-[11px] text-slate-500 mt-0.5">DTR &amp; Part Tagging</div>
                {activeStep >= 1 && (
                  <span className="inline-block mt-2 text-[10px] font-semibold text-amber-700 bg-amber-100/70 px-1.5 py-0.5 rounded">
                    Terkonfirmasi
                  </span>
                )}
              </div>

              {/* Step 2: HMSI */}
              <div className={`p-3 rounded-lg border text-center transition-all ${
                activeStep >= 2 ? 'bg-blue-50 border-blue-300' : 'bg-white border-slate-200 opacity-60'
              }`}>
                <div className="w-7 h-7 mx-auto rounded-full bg-blue-500 text-white flex items-center justify-center text-xs font-bold mb-1.5">
                  2
                </div>
                <div className="font-bold text-slate-900 text-xs">HMSI Technical</div>
                <div className="text-[11px] text-slate-500 mt-0.5">Lab Test &amp; Screening</div>
                {activeStep >= 2 ? (
                  <span className="inline-block mt-2 text-[10px] font-semibold text-blue-700 bg-blue-100/70 px-1.5 py-0.5 rounded">
                    Diproses HMSI
                  </span>
                ) : (
                  <span className="inline-block mt-2 text-[10px] text-slate-400">Menunggu</span>
                )}
              </div>

              {/* Step 3: HMMI/HML */}
              <div className={`p-3 rounded-lg border text-center transition-all ${
                activeStep >= 3 ? 'bg-emerald-50 border-emerald-300' : 'bg-white border-slate-200 opacity-60'
              }`}>
                <div className="w-7 h-7 mx-auto rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-bold mb-1.5">
                  3
                </div>
                <div className="font-bold text-slate-900 text-xs">HMMI / HML Pabrik</div>
                <div className="text-[11px] text-slate-500 mt-0.5">QA Judgement &amp; Replaced</div>
                {activeStep >= 3 ? (
                  <span className="inline-block mt-2 text-[10px] font-semibold text-emerald-700 bg-emerald-100/70 px-1.5 py-0.5 rounded">
                    Approved / Selesai
                  </span>
                ) : (
                  <span className="inline-block mt-2 text-[10px] text-slate-400">Menunggu</span>
                )}
              </div>
            </div>

            <div className="mt-3 pt-3 border-t border-slate-200 flex items-center justify-between text-xs text-slate-600">
              <span>Status Terkini: <strong>{record.status_detail}</strong></span>
              <span className="font-mono text-slate-500">Putusan QPI: {record.judgement_qpi}</span>
            </div>
          </div>

          {/* Vehicle & Claim Specs Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Column 1: Unit & Owner Specs */}
            <div className="border border-slate-200 rounded-xl p-4 space-y-3">
              <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
                <Truck className="w-4 h-4 text-red-600" />
                <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wide">
                  Identifikasi Kendaraan
                </h4>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-slate-500 block text-[11px]">Model Kendaraan</span>
                  <span className="font-semibold text-slate-900">{record.model}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[11px]">Jarak Tempuh (Odometer)</span>
                  <span className="font-mono font-bold text-slate-900">
                    {record.mileage?.toLocaleString('id-ID')} km
                  </span>
                </div>
                <div className="col-span-2">
                  <span className="text-slate-500 block text-[11px]">Nomor Rangka (Chassis / VIN)</span>
                  <span className="font-mono font-bold text-slate-800 bg-slate-100 px-2 py-0.5 rounded">
                    {record.chassis_number}
                  </span>
                </div>
                <div className="col-span-2">
                  <span className="text-slate-500 block text-[11px]">Nomor Mesin (Engine No)</span>
                  <span className="font-mono font-bold text-slate-800 bg-slate-100 px-2 py-0.5 rounded">
                    {record.engine_number}
                  </span>
                </div>
                <div className="col-span-2 pt-1 border-t border-slate-100">
                  <span className="text-slate-500 block text-[11px]">Nama Pemilik / Pelanggan</span>
                  <span className="font-semibold text-slate-900 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-slate-400" />
                    {record.owner_name}
                  </span>
                </div>
              </div>
            </div>

            {/* Column 2: Dealer & Judgement Details */}
            <div className="border border-slate-200 rounded-xl p-4 space-y-3">
              <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
                <Building className="w-4 h-4 text-blue-600" />
                <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wide">
                  Detail Bengkel &amp; Legalitas
                </h4>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="col-span-2">
                  <span className="text-slate-500 block text-[11px]">Nama Dealer Pelapor</span>
                  <span className="font-semibold text-slate-900">{record.dealer_name}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[11px]">Tanggal Putusan</span>
                  <span className="font-mono font-medium text-slate-900 flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-slate-400" />
                    {record.judgement_date}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[11px]">Kuantitas Part Rusak</span>
                  <span className="font-mono font-bold text-red-600">{record.quantity} Unit Part</span>
                </div>
                <div className="col-span-2">
                  <span className="text-slate-500 block text-[11px]">Nomor Judgement QPI</span>
                  <span className="font-mono font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-100">
                    {record.judgement_qpi}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Failure Symptom / Deskripsi Kerusakan */}
          <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50">
            <div className="flex items-center gap-2 mb-2">
              <AlertCircle className="w-4 h-4 text-amber-600" />
              <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wide">
                Gejala Kerusakan &amp; Investigasi Lapangan (Failure Symptom)
              </h4>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed bg-white p-3 rounded-lg border border-slate-200">
              {record.failure_symptom || 'Tidak ada catatan kerusakan tambahan pada laporan DTR ini.'}
            </p>
          </div>

          {/* Part Evidence & Visual Reference */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="rounded-xl border border-slate-200 overflow-hidden bg-slate-900 relative aspect-video flex items-center justify-center">
              <img
                src="/src/assets/images/hino_engine_part_1792158559395.jpg"
                alt="Foto Komponen Mesin OPF"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-2.5">
                <span className="text-[11px] text-white font-medium">
                  Dokumentasi Fisik Part OPF &amp; Lab Sample
                </span>
              </div>
            </div>

            <div className="rounded-xl border border-slate-200 overflow-hidden bg-slate-900 relative aspect-video flex items-center justify-center">
              <img
                src="/src/assets/images/hino_truck_fleet_1792158559046.jpg"
                alt="Unit Hino di Bengkel"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-2.5">
                <span className="text-[11px] text-white font-medium">
                  Unit Commercial Vehicle Hino di Bengkel Resmi
                </span>
              </div>
            </div>
          </div>

          {/* Update Stage Section (Optional Interactive Action) */}
          {onUpdateStatus && (
            <div className="pt-4 border-t border-slate-200">
              <h4 className="font-bold text-slate-900 text-xs mb-2">
                Perbarui Tahapan Alur Klaim (Manual Override)
              </h4>
              <div className="flex flex-col sm:flex-row gap-3">
                <select
                  value={currentStage}
                  onChange={(e) => setCurrentStage(e.target.value as any)}
                  className="px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white text-slate-800"
                >
                  <option value="Dealer">Tahap 1: Dealer (Draft / Submitted)</option>
                  <option value="HMSI">Tahap 2: HMSI (Screening / Under Review)</option>
                  <option value="HMMI/HML">Tahap 3: HMMI/HML (Completed / Approved)</option>
                </select>

                <input
                  type="text"
                  value={detailStatus}
                  onChange={(e) => setDetailStatus(e.target.value)}
                  placeholder="Catatan status detail..."
                  className="flex-1 px-3 py-2 text-xs border border-slate-300 rounded-lg text-slate-800"
                />

                <button
                  onClick={handleSaveStatus}
                  disabled={isUpdating}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg transition-colors whitespace-nowrap"
                >
                  {isUpdating ? 'Menyimpan...' : 'Simpan Perubahan'}
                </button>
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>Dibuat: {record.created_at || 'Sistem Terotomasi'}</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-white border border-slate-300 text-slate-700 font-medium rounded-lg hover:bg-slate-50"
          >
            Tutup
          </button>
        </div>

      </div>
    </div>
  );
};
