import React, { useState } from 'react';
import { X, PlusCircle, Truck, FileText, Check } from 'lucide-react';
import { OpfRecord } from '../types';

interface ManualEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (record: OpfRecord) => Promise<void>;
}

export const ManualEntryModal: React.FC<ManualEntryModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
}) => {
  if (!isOpen) return null;

  const [dtrNumber, setDtrNumber] = useState(`DTR-2026-JKT-${Math.floor(1000 + Math.random() * 9000)}`);
  const [partName, setPartName] = useState('Turbocharger Assembly');
  const [quantity, setQuantity] = useState(1);
  const [model, setModel] = useState('Hino 500 FM 260 JD (6x4 Dump)');
  const [chassisNumber, setChassisNumber] = useState('MHFJ1JGBMK00' + Math.floor(1000 + Math.random() * 9000));
  const [engineNumber, setEngineNumber] = useState('J08E-WD' + Math.floor(10000 + Math.random() * 90000));
  const [mileage, setMileage] = useState(35000);
  const [dealerName, setDealerName] = useState('PT Duta Cemerlang Motors - Jakarta Barat');
  const [judgementDate, setJudgementDate] = useState(new Date().toISOString().split('T')[0]);
  const [judgementQpi, setJudgementQpi] = useState('Draft QPI');
  const [ownerName, setOwnerName] = useState('PT Sinar Mas Logistik');
  const [statusStage, setStatusStage] = useState<'Dealer' | 'HMSI' | 'HMMI/HML'>('Dealer');
  const [statusDetail, setStatusDetail] = useState('Draft - Menunggu Foto Fisik & Tag OPF');
  const [failureSymptom, setFailureSymptom] = useState('Kebocoran oli pada shaft impeller dan getaran saat akselerasi.');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!dtrNumber || !partName || !chassisNumber) {
      alert('Harap lengkapi Nomor DTR, Part Name, dan No. Chassis.');
      return;
    }

    setIsSubmitting(true);
    try {
      await onSubmit({
        dtr_number: dtrNumber,
        part_name: partName,
        quantity: Number(quantity) || 1,
        model,
        chassis_number: chassisNumber,
        engine_number: engineNumber,
        mileage: Number(mileage) || 0,
        dealer_name: dealerName,
        judgement_date: judgementDate,
        judgement_qpi: judgementQpi,
        owner_name: ownerName,
        status_stage: statusStage,
        status_detail: statusDetail,
        failure_symptom: failureSymptom,
      });
      onClose();
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <PlusCircle className="w-5 h-5 text-red-500" />
            <h3 className="font-bold text-sm sm:text-base">Input Data Klaim OPF / DTR Baru</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4 text-xs sm:text-sm">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Nomor DTR */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Nomor DTR <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                required
                value={dtrNumber}
                onChange={(e) => setDtrNumber(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono text-xs focus:ring-1 focus:ring-red-500 focus:outline-none"
              />
            </div>

            {/* Part Name */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Part Name (Komponen OPF) <span className="text-red-500">*</span>
              </label>
              <select
                value={partName}
                onChange={(e) => setPartName(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:ring-1 focus:ring-red-500 focus:outline-none"
              >
                <option value="Turbocharger Assembly">Turbocharger Assembly</option>
                <option value="King Pin & Bushing Set">King Pin & Bushing Set</option>
                <option value="Leaf Spring Rear No. 1">Leaf Spring Rear No. 1</option>
                <option value="Clutch Booster Assembly">Clutch Booster Assembly</option>
                <option value="Common Rail High Pressure Pump">Common Rail High Pressure Pump</option>
                <option value="Brake Chamber Rear Diaphragm">Brake Chamber Rear Diaphragm</option>
                <option value="Water Pump Assembly">Water Pump Assembly</option>
                <option value="Universal Joint Propeller Shaft">Universal Joint Propeller Shaft</option>
                <option value="Lainnya">Lainnya...</option>
              </select>
            </div>

            {/* Quantity */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Jumlah / Quantity
              </label>
              <input
                type="number"
                min={1}
                value={quantity}
                onChange={(e) => setQuantity(Number(e.target.value))}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono text-xs focus:ring-1 focus:ring-red-500 focus:outline-none"
              />
            </div>

            {/* Model Kendaraan */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Model Kendaraan Hino
              </label>
              <select
                value={model}
                onChange={(e) => setModel(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:ring-1 focus:ring-red-500 focus:outline-none"
              >
                <option value="Hino 500 FM 260 JD (6x4 Dump)">Hino 500 FM 260 JD (6x4 Dump)</option>
                <option value="Hino Dutro 300 130 HD (4x2)">Hino Dutro 300 130 HD (4x2)</option>
                <option value="Hino 500 FL 260 JW (6x2 Cargo)">Hino 500 FL 260 JW (6x2 Cargo)</option>
                <option value="Hino 500 FG 235 JJ (4x2)">Hino 500 FG 235 JJ (4x2)</option>
                <option value="Hino 500 FM 350 TH (Tractor Head)">Hino 500 FM 350 TH (Tractor Head)</option>
                <option value="Hino Dutro 300 110 SDB (Microbus)">Hino Dutro 300 110 SDB (Microbus)</option>
                <option value="Hino 700 Profia">Hino 700 Profia</option>
              </select>
            </div>

            {/* Chassis Number */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                No. Chassis (Ch) <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                required
                value={chassisNumber}
                onChange={(e) => setChassisNumber(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono text-xs focus:ring-1 focus:ring-red-500 focus:outline-none"
              />
            </div>

            {/* Engine Number */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                No. Engine (EG)
              </label>
              <input
                type="text"
                value={engineNumber}
                onChange={(e) => setEngineNumber(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono text-xs focus:ring-1 focus:ring-red-500 focus:outline-none"
              />
            </div>

            {/* Mileage */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Mileage / Odometer (km)
              </label>
              <input
                type="number"
                value={mileage}
                onChange={(e) => setMileage(Number(e.target.value))}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono text-xs focus:ring-1 focus:ring-red-500 focus:outline-none"
              />
            </div>

            {/* Judgement Date */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Judgement Date
              </label>
              <input
                type="date"
                value={judgementDate}
                onChange={(e) => setJudgementDate(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:ring-1 focus:ring-red-500 focus:outline-none"
              />
            </div>

            {/* Dealer Name */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Dealer Name
              </label>
              <input
                type="text"
                value={dealerName}
                onChange={(e) => setDealerName(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:ring-1 focus:ring-red-500 focus:outline-none"
              />
            </div>

            {/* Owner Name */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Nama Pemilik / Customer
              </label>
              <input
                type="text"
                value={ownerName}
                onChange={(e) => setOwnerName(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:ring-1 focus:ring-red-500 focus:outline-none"
              />
            </div>

            {/* Stage Selection */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Tahap Alur Klaim
              </label>
              <select
                value={statusStage}
                onChange={(e) => {
                  const stage = e.target.value as 'Dealer' | 'HMSI' | 'HMMI/HML';
                  setStatusStage(stage);
                  if (stage === 'Dealer') setStatusDetail('Draft - Menunggu Foto Fisik & Tag OPF');
                  else if (stage === 'HMSI') setStatusDetail('Screening HMSI - Waiting Technical Feedback');
                  else setStatusDetail('Approved - Part Replaced');
                }}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:ring-1 focus:ring-red-500 focus:outline-none"
              >
                <option value="Dealer">Tahap 1: Draft / Dealer</option>
                <option value="HMSI">Tahap 2: Processed / HMSI</option>
                <option value="HMMI/HML">Tahap 3: Completed / HMMI-HML</option>
              </select>
            </div>

            {/* Judgement QPI */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Judgement QPI
              </label>
              <input
                type="text"
                value={judgementQpi}
                onChange={(e) => setJudgementQpi(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:ring-1 focus:ring-red-500 focus:outline-none"
              />
            </div>

            {/* Status Detail */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Detail Status Progres
              </label>
              <input
                type="text"
                value={statusDetail}
                onChange={(e) => setStatusDetail(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:ring-1 focus:ring-red-500 focus:outline-none"
              />
            </div>

            {/* Failure Symptom */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Gejala Kerusakan (Failure Symptom)
              </label>
              <textarea
                rows={2}
                value={failureSymptom}
                onChange={(e) => setFailureSymptom(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 text-xs focus:ring-1 focus:ring-red-500 focus:outline-none"
              />
            </div>

          </div>

          {/* Form Actions */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-300 text-slate-700 text-xs font-semibold rounded-lg hover:bg-slate-50 transition-colors"
            >
              Batal
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
            >
              <Check className="w-4 h-4" />
              <span>{isSubmitting ? 'Menyimpan...' : 'Simpan Rekord DTR'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
