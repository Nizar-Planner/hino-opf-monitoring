import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { WorkflowTrackerCards } from './components/WorkflowTrackerCards';
import { AnalyticsCharts } from './components/AnalyticsCharts';
import { DataTable } from './components/DataTable';
import { DetailModal } from './components/DetailModal';
import { ManualEntryModal } from './components/ManualEntryModal';
import { DeployGuideModal } from './components/DeployGuideModal';
import { SyncLogsModal } from './components/SyncLogsModal';
import { OpfRecord, StatsData, SyncStatus, SyncLog } from './types';
import { Truck, AlertCircle, CheckCircle2, Shield, ArrowUpRight } from 'lucide-react';

export default function App() {
  const [records, setRecords] = useState<OpfRecord[]>([]);
  const [stats, setStats] = useState<StatsData | null>(null);
  const [syncStatus, setSyncStatus] = useState<SyncStatus | null>(null);
  const [syncLogs, setSyncLogs] = useState<SyncLog[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);

  // Filters & State
  const [searchTerm, setSearchTerm] = useState('');
  const [activeStageFilter, setActiveStageFilter] = useState<'all' | 'dealer' | 'hmsi' | 'hmmi_hml'>('all');
  
  // Modals
  const [selectedRecord, setSelectedRecord] = useState<OpfRecord | null>(null);
  const [isManualModalOpen, setIsManualModalOpen] = useState(false);
  const [isGuideModalOpen, setIsGuideModalOpen] = useState(false);
  const [isSyncLogsModalOpen, setIsSyncLogsModalOpen] = useState(false);

  // Notification Toast
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Fetch all data
  const fetchData = useCallback(async () => {
    try {
      setIsLoading(true);
      const [recRes, statsRes, statusRes, logsRes] = await Promise.all([
        fetch('/api/opf').then((r) => r.json()),
        fetch('/api/stats').then((r) => r.json()),
        fetch('/api/sync/status').then((r) => r.json()),
        fetch('/api/sync/logs').then((r) => r.json()),
      ]);

      if (recRes.success) setRecords(recRes.data);
      if (statsRes.success) setStats(statsRes.data);
      if (statusRes.success) setSyncStatus(statusRes.data);
      if (logsRes.success) setSyncLogs(logsRes.data);
    } catch (err) {
      console.error('Error fetching dashboard data:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Handle Trigger Scraper Sync
  const handleSync = async () => {
    if (isSyncing) return;
    setIsSyncing(true);
    try {
      const res = await fetch('/api/sync/trigger', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      }).then((r) => r.json());

      if (res.success) {
        showToast(res.data.message || 'Sinkronisasi data HIS berhasil diselesaikan!', 'success');
        await fetchData();
      } else {
        showToast(res.error || 'Gagal sinkronisasi data HIS.', 'error');
      }
    } catch (err) {
      console.error(err);
      showToast('Koneksi sinkronisasi gagal.', 'error');
    } finally {
      setIsSyncing(false);
    }
  };

  // Handle Manual Add / Edit
  const handleCreateOrUpdate = async (record: OpfRecord) => {
    try {
      const res = await fetch('/api/opf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(record),
      }).then((r) => r.json());

      if (res.success) {
        showToast(res.message || 'Data OPF berhasil disimpan.', 'success');
        await fetchData();
      } else {
        showToast(res.error || 'Gagal menyimpan data.', 'error');
      }
    } catch (err) {
      console.error(err);
      showToast('Terjadi kesalahan saat menyimpan data.', 'error');
    }
  };

  // Handle Delete
  const handleDeleteRecord = async (id: number) => {
    try {
      const res = await fetch(`/api/opf/${id}`, { method: 'DELETE' }).then((r) => r.json());
      if (res.success) {
        showToast('Data klaim OPF berhasil dihapus.', 'success');
        await fetchData();
        if (selectedRecord?.id === id) {
          setSelectedRecord(null);
        }
      } else {
        showToast(res.error || 'Gagal menghapus data.', 'error');
      }
    } catch (err) {
      console.error(err);
      showToast('Gagal menghubungi server.', 'error');
    }
  };

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 font-sans antialiased">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-lg border text-xs sm:text-sm font-semibold transition-all transform animate-bounce bg-white border-slate-200 text-slate-800">
          {toastMessage.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          ) : (
            <AlertCircle className="w-5 h-5 text-red-600 shrink-0" />
          )}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Main Header */}
      <Header
        onSync={handleSync}
        isSyncing={isSyncing}
        syncStatus={syncStatus}
        onOpenManualEntry={() => setIsManualModalOpen(true)}
        onOpenGuide={() => setIsGuideModalOpen(true)}
        onOpenSyncLogs={() => setIsSyncLogsModalOpen(true)}
        activeTab={activeStageFilter}
        setActiveTab={setActiveStageFilter}
      />

      {/* Page Content Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        
        {/* Hero Context Banner with Genuine Hino Fleet Photography */}
        <div className="relative rounded-2xl overflow-hidden border border-slate-200 bg-slate-900 shadow-xs">
          <div className="absolute inset-0">
            <img
              src="/src/assets/images/hino_truck_fleet_1792158559046.jpg"
              alt="Armada Kendaraan Komersial Hino"
              className="w-full h-full object-cover opacity-25"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/90 to-transparent"></div>
          </div>

          <div className="relative p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="max-w-2xl space-y-2">
              <div className="flex items-center gap-2 text-xs font-semibold text-red-400">
                <Truck className="w-4 h-4" />
                <span>HINO COMMERCIAL VEHICLES INDONESIA</span>
                <span>·</span>
                <span className="text-slate-300">OPF QUALITY ASSURANCE</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
                Sistem Monitoring &amp; Tracking OPF Terintegrasi
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Platform otomatisasi penarikan data dari portal HIS secara headless, mengawasi siklus investigasi teknis DTR dari tahap submission Dealer &rarr; screening HMSI &rarr; hingga keputusan garansi HMMI / HML Japan.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 shrink-0">
              <button
                onClick={() => setIsGuideModalOpen(true)}
                className="flex items-center justify-center gap-2 px-4 py-2.5 bg-white hover:bg-slate-100 text-slate-900 rounded-lg text-xs font-bold transition-colors shadow-sm"
              >
                <span>Cara Pasang di Render.com</span>
                <ArrowUpRight className="w-4 h-4 text-slate-500" />
              </button>
            </div>
          </div>
        </div>

        {/* 1. Workflow Stage Cards: Dealer -> HMSI -> HMMI/HML */}
        <WorkflowTrackerCards
          stats={stats}
          activeTab={activeStageFilter}
          onSelectTab={setActiveStageFilter}
        />

        {/* 2. Analytics Charts: Top 5 OPF & Vehicle Model Distribution */}
        <AnalyticsCharts
          stats={stats}
          onFilterByPart={(partName) => setSearchTerm(partName)}
          onFilterByModel={(modelName) => setSearchTerm(modelName)}
        />

        {/* 3. Comprehensive Data Table & Search */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Data Master Laporan DTR &amp; Investigasi OPF
              </h3>
              <p className="text-xs text-slate-500">
                Ditarik otomatis oleh robot scraper atau diinput manual oleh teknisi lapangan
              </p>
            </div>
          </div>

          <DataTable
            records={records}
            isLoading={isLoading}
            onSelectRecord={(rec) => setSelectedRecord(rec)}
            onDeleteRecord={handleDeleteRecord}
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            activeStageFilter={activeStageFilter}
            setActiveStageFilter={setActiveStageFilter}
          />
        </div>

      </main>

      {/* Footer */}
      <footer className="mt-12 border-t border-slate-200 bg-white py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="w-5 h-5 rounded bg-red-600 text-white font-black text-xs flex items-center justify-center">
              H
            </span>
            <span className="font-semibold text-slate-800">
              Hino Motors OPF Quality Tracking System
            </span>
            <span>·</span>
            <span>SQLite Embedded Database</span>
          </div>
          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <span>Siap Deploy di Render.com Free Tier</span>
            <span>·</span>
            <span>Automated Chromium Headless Scraper</span>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <DetailModal
        record={selectedRecord}
        onClose={() => setSelectedRecord(null)}
        onUpdateStatus={async (updated) => {
          await handleCreateOrUpdate(updated);
          setSelectedRecord(updated);
        }}
      />

      <ManualEntryModal
        isOpen={isManualModalOpen}
        onClose={() => setIsManualModalOpen(false)}
        onSubmit={handleCreateOrUpdate}
      />

      <DeployGuideModal
        isOpen={isGuideModalOpen}
        onClose={() => setIsGuideModalOpen(false)}
      />

      <SyncLogsModal
        isOpen={isSyncLogsModalOpen}
        onClose={() => setIsSyncLogsModalOpen(false)}
        logs={syncLogs}
        status={syncStatus}
        onTriggerSync={handleSync}
        isSyncing={isSyncing}
      />
    </div>
  );
}
