export interface OpfRecord {
  id?: number;
  dtr_number: string;
  part_name: string;
  quantity: number;
  model: string;
  chassis_number: string;
  engine_number: string;
  mileage: number;
  dealer_name: string;
  judgement_date: string;
  judgement_qpi: string;
  owner_name: string;
  status_stage: 'Dealer' | 'HMSI' | 'HMMI/HML';
  status_detail: string;
  failure_symptom?: string;
  created_at?: string;
  updated_at?: string;
}

export interface StatsData {
  totalRecords: number;
  stageCounts: {
    dealer: number;
    hmsi: number;
    hmmi_hml: number;
  };
  topParts: {
    name: string;
    count: number;
  }[];
  modelDistribution: {
    model: string;
    count: number;
  }[];
  recentActivity: OpfRecord[];
}

export interface SyncStatus {
  isRunning: boolean;
  lastRunTimestamp: string | null;
  lastRunStatus: 'idle' | 'success' | 'failed' | 'simulated';
  lastRunMessage: string;
  nextScheduledRun: string | null;
  totalSyncedCount: number;
}

export interface SyncLog {
  id?: number;
  timestamp: string;
  status: 'success' | 'failed' | 'running';
  records_extracted: number;
  records_new: number;
  records_updated: number;
  message: string;
  duration_ms: number;
}
