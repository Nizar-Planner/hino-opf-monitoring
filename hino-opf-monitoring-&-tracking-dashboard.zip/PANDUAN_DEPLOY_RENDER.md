# 🚚 Panduan Lengkap Deploy Dashboard OPF Hino ke Render.com (Gratis)
*Khusus untuk Pemula (Tanpa Perlu Coding atau Menguasai Terminal)*

Dokumen ini memandu Anda langkah demi langkah dari nol untuk memasukkan kode aplikasi ini ke akun **GitHub** (cukup lewat browser web) lalu menghubungkannya ke layanan hosting gratis **Render.com**.

---

## 📑 Daftar Isi
1. [Persiapan Awal (Gratis)](#1-persiapan-awal)
2. [Langkah 1: Download Seluruh Kode Proyek](#langkah-1-download-seluruh-kode-proyek)
3. [Langkah 2: Buat Repositori di GitHub (Lewat Browser)](#langkah-2-buat-repositori-di-github)
4. [Langkah 3: Hubungkan dan Deploy di Render.com](#langkah-3-hubungkan-dan-deploy-di-rendercom)
5. [Langkah 4: Masukkan Username & Password HIS](#langkah-4-masukkan-username--password-his)
6. [Langkah 5: Selesai! Website Anda Sudah Aktif](#langkah-5-selesai)

---

### 1. Persiapan Awal
Pastikan Anda sudah memiliki:
1. Akun **GitHub** (daftar gratis di [github.com](https://github.com)).
2. Akun **Render** (daftar gratis di [render.com](https://render.com) — bisa langsung login pakai akun GitHub Anda).
3. Username & Password akun portal HIS Hino Anda.

---

### Langkah 1: Download Seluruh Kode Proyek
1. Jika Anda berada di AI Studio, Anda dapat mengunduh seluruh berkas proyek ini sebagai file `.zip` (atau klik menu Download Code/Export).
2. Ekstrak file zip tersebut di komputer atau laptop Anda sehingga muncul folder yang berisi file-file seperti `Dockerfile`, `package.json`, `server.ts`, folder `src`, dll.

---

### Langkah 2: Buat Repositori di GitHub (Lewat Browser)
1. Buka [github.com](https://github.com) dan login.
2. Di pojok kanan atas, klik tanda tambah **`+`** lalu pilih **"New repository"**.
3. Isi data berikut:
   - **Repository name**: `hino-opf-monitoring`
   - Pilih: **Private** (sangat disarankan agar data internal aman) atau **Public**.
   - Biarkan opsi lainnya kosong.
   - Klik tombol hijau **"Create repository"**.
4. Di halaman repositori baru yang muncul, cari tulisan:
   *"Get started by creating a new file or uploading an existing file."*
   -> Klik link **"uploading an existing file"**.
5. Drag & Drop (seret dan lepas) semua file dan folder dari hasil ekstrak tadi ke dalam kotak browser GitHub:
   - Pastikan file `Dockerfile`, `package.json`, `server.ts`, `render.yaml`, dan folder `src` ter-upload.
   *(Catatan: Folder `node_modules` tidak perlu di-upload karena sudah otomatis diabaikan).*
6. Gulir ke bawah, lalu klik tombol hijau **"Commit changes"**.
7. Sekarang seluruh kode aplikasi Anda sudah tersimpan rapi di GitHub!

---

### Langkah 3: Hubungkan dan Deploy di Render.com
1. Buka [dashboard.render.com](https://dashboard.render.com) dan login.
2. Di dashboard Render, klik tombol **"New +"** (di pojok kanan atas) lalu pilih **"Web Service"**.
3. Pilih opsi **"Build and deploy from a Git repository"** lalu klik **Next**.
4. Cari dan pilih repositori GitHub Anda tadi: `hino-opf-monitoring` (klik tombol **Connect**).
5. Pada formulir konfigurasi yang muncul:
   - **Name**: Beri nama, misalnya `hino-opf-tracker` (nama ini akan menjadi alamat URL Anda: `https://hino-opf-tracker.onrender.com`).
   - **Region**: Pilih **Singapore (Southeast Asia)** agar akses dari Indonesia super cepat.
   - **Language / Runtime**: Render akan otomatis mendeteksi **Docker** karena sudah ada file `Dockerfile` yang kami siapkan. Jika belum, pilih runtime **Docker**.
   - **Instance Type**: Pilih **Free** (Rp 0 / gratis).

---

### Langkah 4: Masukkan Username & Password HIS
Sebelum menekan tombol deploy, gulir ke bagian **"Environment Variables"** di halaman Render yang sama:
1. Klik **"Add Environment Variable"**:
   - **Key**: `HIS_USER`
   - **Value**: Masukkan username login HIS Hino Anda.
2. Klik **"Add Environment Variable"** lagi:
   - **Key**: `HIS_PASSWORD`
   - **Value**: Masukkan password akun HIS Hino Anda.
3. (Opsional) Tambahkan variabel:
   - **Key**: `SYNC_INTERVAL_HOURS`
   - **Value**: `3` (artinya robot akan otomatis login dan menarik data setiap 3 jam).

> 🔒 **Penting Soal Keamanan:** Password dan Username Anda disimpan di brankas enkripsi Render, bukan di kode umum, sehingga tidak akan pernah bocor atau terlihat oleh orang lain.

4. Klik tombol **"Create Web Service"** di bagian paling bawah.

---

### Langkah 5: Selesai!
1. Render akan mulai memproses: memasang Linux, Chromium, database SQLite, dan menyalakan robot otomatis.
2. Proses ini memakan waktu sekitar 3–5 menit untuk pertama kali.
3. Setelah status berubah menjadi hijau **"Live"**, klik alamat URL di atas (contoh: `https://hino-opf-tracker.onrender.com`).
4. 🎉 **Selamat!** Dashboard Monitoring OPF Hino Anda kini sudah aktif 24 jam nonstop di internet tanpa perlu sewa server mahal!

---

### 💡 Fitur Unggulan Dashboard Anda:
- **Tracking Alur Klaim Real-time**: Memantau perpindahan status dari **Dealer** -> **HMSI** -> **HMMI/HML**.
- **Analisis Grafik Top 5 OPF**: Mengetahui komponen mana yang paling sering rusak dan perlu perhatian khusus.
- **Pencarian Cepat Multi-Kolom**: Cari berdasarkan No. DTR, No. Chassis, No. Engine, Dealer, atau Part Name.
- **Ekspor CSV**: Download laporan lengkap untuk dibuka langsung di Microsoft Excel.
- **Tombol Tarik Data Manual**: Tombol "Sinkronkan Sekarang" di dashboard untuk menarik data kapan saja tanpa menunggu 3 jam.
